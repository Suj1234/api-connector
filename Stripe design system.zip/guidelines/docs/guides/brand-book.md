# Stripe Dashboard brand book

The visual language of Stripe's web dashboard, onboarding and sign-in, rebuilt from 568 screenshots (January 2025). Dense, calm, white. Colour is spent on two things only: what you can act on (blurple) and what state an object is in (tinted badges). This is an unofficial study; it ships no Stripe logos or icon files.

In React, use the components on `window.StripeDashboard`; they render the `.sd-*` classes from `styles.css`, which read only tokens.

## Content fundamentals

- **Sentence case everywhere**: page titles ("Product catalogue"), buttons ("Create payment"), tabs ("All activity"), column headers ("Refunded date"). Uppercase only for `overline` eyebrows ("PAYMENT").
- **Verb-first actions, object named**: "Create payment", "Send invoice", "Add tax rate", "Pay out MYR 5.00", "Refund MYR 0.50". The primary in a modal repeats the amount it will move.
- **"You" and "your"**, never "we" for the user's data: "Add an account for payouts. Earnings that you receive will be sent to this account." Stripe speaks as "Stripe" in the third person: "Stripe requires two-step authentication…".
- **Explain the consequence under the choice**: "Create an invoice requesting payment on a specific date." Help text is one or two plain sentences in `text-muted`.
- **Errors say what to fix**: "Amount must be at least RM2.00 myr", "Your password works, but could be stronger. Try making it longer."
- **Confirmations are past tense and specific**: "Customer created", "Invoice sent to iamleonardkim@gmail.com", "Your changes have been saved".
- **Money is currency-first with the ISO code**: "MYR 2.00", "US$1.00 USD", negative as "−MYR 1.08". Dates: "6 Dec 2024, 00:42"; short in tables: "6 Dec, 00:42".
- **Empty values are an em dash** in `text-placeholder`, never blank or "N/A".
- No emoji. Exclamation marks only in greetings ("Welcome back, Sam!").

## Visual foundations

**Colour.** Pages, cards, tables and modals are `surface` (white). Recess with `surface-subdued` (`gray-50`) for search, banners and onboarding panels. Text is `text` (`gray-800`); titles `text-heading`; labels `text-subdued`; timestamps and help `text-muted`. Borders: `border` for dividers and card outlines, `border-strong` for controls and the rule under section headings.
`brand` (`blurple-500` #635bff) fills the one primary action per view, checked controls, the active stepper node and the quick-create plus. `text-link` (`blurple-700`) colours links, the active nav item, the selected tab and menu actions. Don't use blurple for decoration.
Status lives in tinted badges: success `green-100`/`green-700`, danger `red-100`/`red-700`, info `blue-100`/`blue-700`, warning `yellow-100`/`yellow-700`, neutral `gray-100`/`gray-700`. Destructive buttons are `red-500`.
`orange-500` belongs to Test mode only (the top bar and the switch). `navy-900` is for tour popovers and the product-education banner.
Charts: the line is `brand`; breakdown bars use `purple-400` (succeeded), `blue-700` (open), `green-500` (paid), `orange-600` (failed).
Only a light theme exists in the source.

**Type.** Everything is set in Ubuntu Sans (`--font-sans`, variable weights 100–800, loaded from Google Fonts in `tokens.css`), falling back to the system face. `title` 28/36 bold for page titles and detail amounts; `heading` 20/28 bold for in-page sections; `heading-sm` 16/24 bold for cards and modals; `body` 14/20 for almost everything; `body-emphasis` for labels and nav; `caption` 12/16 for timestamps and help; `caption-emphasis` for table headers. `code` (Menlo 13/20) for IDs, keys and JSON. `display` in `--font-display` (also Ubuntu Sans) is only for marketing heroes. Numbers are tabular.

**Spacing and layout.** 4px grid (`space-1` … `space-16`). Sidebar `sidebar-width` 244px, top bar `topbar-height` 60px, page gutters `space-6`. Sections are separated by `space-8` and open with a 20px title over a `border-strong` rule. Detail pages are two columns: content left, a ~280px "Details" rail right. Forms are one column, 320–480px wide, fields `space-4` apart. Focused tasks (create invoice, create link) go full-screen with a FocusHeader and a live preview on the right half.

**Shape.** `radius-xs` 4px badges, tags, checkboxes; `radius-sm` 6px buttons, inputs, banners, count tiles; `radius-md` 8px cards, menus, modals, toasts; `radius-lg` 12px onboarding panels; `radius-full` filter pills and switches.

**Elevation.** Controls sit 1px up with `shadow-control` plus a `border-strong` edge. Primary buttons get `shadow-primary`. Menus, selects and date pickers use `shadow-popover`; modals, drawers, toasts and the auth card use `shadow-modal`. Cards are flat with a `border` outline. The modal scrim is `overlay`.

**States.** Hover darkens borders to `gray-200` or fills rows with `surface-subdued`. Focus is always `shadow-focus`: a 1px `brand` edge plus a 4px translucent blurple halo. Selected tiles and choice cards use a `brand` border and ring. Disabled primaries fill `blurple-300`; disabled secondaries drop the shadow and grey the label. Loading replaces the label with a Spinner in place.

**Motion.** 150ms ease on colour, border and shadow. Popovers and modals fade and rise a few pixels. Respect `prefers-reduced-motion`.

**Imagery.** The dashboard uses product mock-ups (payment link and invoice thumbnails), not photography. The auth and marketing surfaces use the skewed four-stop gradient band: `gradient-yellow`, `gradient-red`, `gradient-purple`, `gradient-cyan`.

## Iconography

Stripe's dashboard icons are 16px, 1.5px stroke, rounded caps, drawn in `gray-600` (nav), `text-subdued` (toolbar) or the status colour. Its icon set isn't reachable from screenshots, so the previews use simple 16px stroke substitutes with the same weight and size. Replace them with the real set when available. Icons always sit beside a label or carry an `aria-label` and Tooltip; status icons (check, x, clock) back up badge colour, never replace the word.

## Using the components

- One primary Button per view, right-most; secondary to its left.
- List pages: PageHeader → Banner (optional) → CountTabs → FilterChip row with Export / Edit columns → Table → Pagination.
- Detail pages: overline + PageHeader with status Badge → Timeline → section titles with DetailsList and breakdowns; a DetailsList rail on the right.
- Create flows: Modal for 1–3 fields, Drawer for a single object with more fields, full-screen FocusHeader + preview for invoices, links and subscriptions.
- Confirmations: Toast. Problems that block the account: critical Banner. Field problems: inline Field error.
- Contrast: body text pairs pass AA on `surface` and `surface-subdued`. `text-placeholder` is decorative only. White on `brand` is 4.7:1 and on `orange-500` 4.6:1. Disabled primaries (white on `blurple-300`, 2:1) are exempt only because they're disabled.
