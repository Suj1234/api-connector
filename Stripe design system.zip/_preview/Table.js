"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.StripeDashboard;
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // .design-sync/previews/Table.tsx
  var Table_exports = {};
  __export(Table_exports, {
    Customers: () => Customers,
    Payments: () => Payments
  });
  init_define_import_meta_env();

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g = window.StripeDashboard;
  var ds_default = "default" in g ? g.default : g;

  // .design-sync/previews/Table.tsx
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  var rows = [
    { id: "py_1", amount: "US$1.00", currency: "USD", status: "Incomplete", description: "Payment for Invoice", customer: "iamleonardkim@gmail.com", date: "6 Dec, 09:00" },
    { id: "py_2", amount: "MYR 2.00", currency: "MYR", status: "Succeeded", last4: "6442", description: "Admin fee", customer: "iamleonardkim@gmail.com", date: "6 Dec, 00:42" },
    { id: "py_3", amount: "MYR 2.00", currency: "MYR", status: "Failed", last4: "0687", description: "Admin fee", customer: "iamleonardkim@gmail.com", date: "6 Dec, 00:41" },
    { id: "py_4", amount: "MYR 2.00", currency: "MYR", status: "Failed", last4: "3785", description: "Admin fee", customer: "dianaford@gmail.com", date: "6 Dec, 00:35" }
  ];
  var statusBadge = (s) => s === "Succeeded" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Badge, { tone: "success", icon: "check", children: "Succeeded" }) : s === "Failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Badge, { tone: "danger", icon: "x", children: "Failed" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Badge, { icon: "clock", children: "Incomplete" });
  var Payments = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    ds_exports.Table,
    {
      rows,
      rowKey: (r) => r.id,
      selectable: true,
      selectedKeys: ["py_2"],
      rowActions: true,
      columns: [
        { key: "amount", header: "Amount", render: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Amount, { value: r.amount, currency: r.currency }) },
        { key: "status", header: "", render: (r) => statusBadge(r.status) },
        { key: "method", header: "Payment method", render: (r) => r.last4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.CardBrand, { last4: r.last4 }) : null },
        { key: "description", header: "Description" },
        { key: "customer", header: "Customer" },
        { key: "date", header: "Date" }
      ],
      footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Pagination, { summary: "4 results", hasNext: true })
    }
  );
  var Customers = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    ds_exports.Table,
    {
      rows: [
        { id: "c1", name: "Diana Ford", email: "iamdianaford@gmail.com", spend: "MYR 0.00", payments: 0, created: "9 Dec, 07:28" },
        { id: "c2", name: "Cindy Jung", email: "itscindyjung@gmail.com", spend: "MYR 0.00", payments: 0, created: "5 Dec, 19:34" },
        { id: "c3", name: "Leonard Kim", email: "iamleonardkim@gmail.com", spend: "MYR 2.00", payments: 1, created: "5 Dec, 18:52" }
      ],
      rowKey: (r) => r.id,
      rowActions: true,
      columns: [
        { key: "name", header: "Name", render: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { style: { color: "var(--text)" }, children: r.name }) },
        { key: "email", header: "Email" },
        { key: "method", header: "Default payment method" },
        { key: "spend", header: "Total spend", align: "end" },
        { key: "payments", header: "Payments", align: "end" },
        { key: "created", header: "Created" }
      ]
    }
  );
  return __toCommonJS(Table_exports);
})();
