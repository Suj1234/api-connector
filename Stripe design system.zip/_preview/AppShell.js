"use strict";
var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.StripeDashboard;
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // .design-sync/previews/AppShell.tsx
  var AppShell_exports = {};
  __export(AppShell_exports, {
    TransactionsPage: () => TransactionsPage
  });
  init_define_import_meta_env();

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g = window.StripeDashboard;
  var ds_default = "default" in g ? g.default : g;

  // .design-sync/previews/AppShell.tsx
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  var TransactionsPage = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { width: 840, height: 600, overflow: "hidden" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
    ds_exports.AppShell,
    {
      testMode: true,
      sidebar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Sidebar, { accountName: "Content-mobbin", accountInitials: "CM", sections: [
        { items: [
          { label: "Home", icon: "home" },
          { label: "Balances", icon: "balances" },
          { label: "Transactions", icon: "transactions", current: true },
          { label: "Customers", icon: "customers" },
          { label: "Product catalogue", icon: "product" }
        ] },
        { label: "Shortcuts", items: [{ label: "Invoices", icon: "clock" }] },
        { label: "Products", items: [
          { label: "Payments", icon: "payments", expandable: true },
          { label: "Billing", icon: "billing", children: [{ label: "Overview" }, { label: "Subscriptions" }, { label: "Invoices" }] },
          { label: "Reporting", icon: "reporting", expandable: true },
          { label: "More", icon: "more", expandable: true }
        ] }
      ] }),
      topBar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.TopBar, { testMode: true, unread: true }),
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.PageHeader, { title: "Transactions", actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Button, { variant: "primary", icon: "plus", children: "Create payment" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Button, { icon: "reporting", children: "Analyse" })
        ] }) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ds_exports.Banner, { actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.Link, { href: "#", children: "Install Xero" }), onDismiss: () => {
        }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Recommendation" }),
          "  Get quick financial insights with the Xero app."
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.CountTabs, { items: [{ label: "All", count: 6 }, { label: "Succeeded", count: 1 }, { label: "Failed", count: 3 }] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", gap: 8, flexWrap: "wrap" }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.FilterChip, { label: "Date and time" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.FilterChip, { label: "Amount" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.FilterChip, { label: "Status" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.FilterChip, { label: "More filters" })
        ] })
      ]
    }
  ) });
  return __toCommonJS(AppShell_exports);
})();
