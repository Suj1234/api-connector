/* @ds-bundle: {"namespace":"StripeDashboard","components":[{"name":"Amount","sourcePath":"components/data-display/Amount/Amount.jsx"},{"name":"AppShell","sourcePath":"components/layout/AppShell/AppShell.jsx"},{"name":"AuthLayout","sourcePath":"components/layout/AuthLayout/AuthLayout.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge/Badge.jsx"},{"name":"Banner","sourcePath":"components/feedback/Banner/Banner.jsx"},{"name":"Breadcrumb","sourcePath":"components/navigation/Breadcrumb/Breadcrumb.jsx"},{"name":"BreakdownBar","sourcePath":"components/data-display/BreakdownBar/BreakdownBar.jsx"},{"name":"BreakdownList","sourcePath":"components/data-display/BreakdownList/BreakdownList.jsx"},{"name":"Button","sourcePath":"components/actions/Button/Button.jsx"},{"name":"Card","sourcePath":"components/layout/Card/Card.jsx"},{"name":"CardBrand","sourcePath":"components/data-display/CardBrand/CardBrand.jsx"},{"name":"ChartCard","sourcePath":"components/data-display/ChartCard/ChartCard.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox/Checkbox.jsx"},{"name":"ChoiceCard","sourcePath":"components/forms/ChoiceCard/ChoiceCard.jsx"},{"name":"ChoiceCardGroup","sourcePath":"components/forms/ChoiceCardGroup/ChoiceCardGroup.jsx"},{"name":"CodeBlock","sourcePath":"components/data-display/CodeBlock/CodeBlock.jsx"},{"name":"ColorInput","sourcePath":"components/forms/ColorInput/ColorInput.jsx"},{"name":"CountTabs","sourcePath":"components/data-display/CountTabs/CountTabs.jsx"},{"name":"DatePicker","sourcePath":"components/forms/DatePicker/DatePicker.jsx"},{"name":"DetailsList","sourcePath":"components/data-display/DetailsList/DetailsList.jsx"},{"name":"Drawer","sourcePath":"components/feedback/Drawer/Drawer.jsx"},{"name":"EmptyState","sourcePath":"components/data-display/EmptyState/EmptyState.jsx"},{"name":"Field","sourcePath":"components/forms/Field/Field.jsx"},{"name":"FilterChip","sourcePath":"components/forms/FilterChip/FilterChip.jsx"},{"name":"FocusHeader","sourcePath":"components/navigation/FocusHeader/FocusHeader.jsx"},{"name":"Hint","sourcePath":"components/actions/Hint/Hint.jsx"},{"name":"Icon","sourcePath":"components/foundations/Icon/Icon.jsx"},{"name":"IdChip","sourcePath":"components/data-display/IdChip/IdChip.jsx"},{"name":"Kbd","sourcePath":"components/actions/Kbd/Kbd.jsx"},{"name":"Link","sourcePath":"components/actions/Link/Link.jsx"},{"name":"Menu","sourcePath":"components/actions/Menu/Menu.jsx"},{"name":"MenuItem","sourcePath":"components/actions/MenuItem/MenuItem.jsx"},{"name":"MenuLabel","sourcePath":"components/actions/MenuLabel/MenuLabel.jsx"},{"name":"MenuSeparator","sourcePath":"components/actions/MenuSeparator/MenuSeparator.jsx"},{"name":"Metric","sourcePath":"components/data-display/Metric/Metric.jsx"},{"name":"Modal","sourcePath":"components/feedback/Modal/Modal.jsx"},{"name":"OTPInput","sourcePath":"components/forms/OTPInput/OTPInput.jsx"},{"name":"PageHeader","sourcePath":"components/layout/PageHeader/PageHeader.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Pagination/Pagination.jsx"},{"name":"PasswordStrength","sourcePath":"components/forms/PasswordStrength/PasswordStrength.jsx"},{"name":"PlusButton","sourcePath":"components/actions/PlusButton/PlusButton.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio/Radio.jsx"},{"name":"RequestLog","sourcePath":"components/data-display/RequestLog/RequestLog.jsx"},{"name":"SearchInput","sourcePath":"components/forms/SearchInput/SearchInput.jsx"},{"name":"SectionTitle","sourcePath":"components/layout/SectionTitle/SectionTitle.jsx"},{"name":"Select","sourcePath":"components/forms/Select/Select.jsx"},{"name":"Sidebar","sourcePath":"components/navigation/Sidebar/Sidebar.jsx"},{"name":"Spinner","sourcePath":"components/feedback/Spinner/Spinner.jsx"},{"name":"Stepper","sourcePath":"components/navigation/Stepper/Stepper.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch/Switch.jsx"},{"name":"Table","sourcePath":"components/data-display/Table/Table.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs/Tabs.jsx"},{"name":"Tag","sourcePath":"components/data-display/Tag/Tag.jsx"},{"name":"TestModeBar","sourcePath":"components/feedback/TestModeBar/TestModeBar.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea/Textarea.jsx"},{"name":"TextInput","sourcePath":"components/forms/TextInput/TextInput.jsx"},{"name":"Timeline","sourcePath":"components/data-display/Timeline/Timeline.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip/Tooltip.jsx"},{"name":"TopBar","sourcePath":"components/navigation/TopBar/TopBar.jsx"},{"name":"TourPopover","sourcePath":"components/feedback/TourPopover/TourPopover.jsx"}],"sourceHashes":{"components/data-display/Amount/Amount.jsx":"10dbf5be9399","components/data-display/Amount/Amount.d.ts":"2707e0742d84","components/data-display/Amount/Amount.prompt.md":"5fbd34a5d8d4","components/layout/AppShell/AppShell.jsx":"acbdf32e4c43","components/layout/AppShell/AppShell.d.ts":"6cdec258e159","components/layout/AppShell/AppShell.prompt.md":"2ce2a95d204b","components/layout/AuthLayout/AuthLayout.jsx":"5ab7fa6c24cb","components/layout/AuthLayout/AuthLayout.d.ts":"519598b0b904","components/layout/AuthLayout/AuthLayout.prompt.md":"3571f171212d","components/data-display/Badge/Badge.jsx":"4f5918ef6807","components/data-display/Badge/Badge.d.ts":"d2bdc935b20b","components/data-display/Badge/Badge.prompt.md":"83abc2a6dada","components/feedback/Banner/Banner.jsx":"22f686f50d04","components/feedback/Banner/Banner.d.ts":"204bc4d4b966","components/feedback/Banner/Banner.prompt.md":"2211bf6d0dac","components/navigation/Breadcrumb/Breadcrumb.jsx":"1f75a765a740","components/navigation/Breadcrumb/Breadcrumb.d.ts":"22cab801909a","components/navigation/Breadcrumb/Breadcrumb.prompt.md":"e686996f0d33","components/data-display/BreakdownBar/BreakdownBar.jsx":"60c0085252d6","components/data-display/BreakdownBar/BreakdownBar.d.ts":"72f1f66962f5","components/data-display/BreakdownBar/BreakdownBar.prompt.md":"082da2ea47de","components/data-display/BreakdownList/BreakdownList.jsx":"f3062e9f45d6","components/data-display/BreakdownList/BreakdownList.d.ts":"c370cf8f9da1","components/data-display/BreakdownList/BreakdownList.prompt.md":"b2104f13c301","components/actions/Button/Button.jsx":"af0995cb31a0","components/actions/Button/Button.d.ts":"387566e0f49b","components/actions/Button/Button.prompt.md":"47ebb86697a1","components/layout/Card/Card.jsx":"9873d785031d","components/layout/Card/Card.d.ts":"55503d663e36","components/layout/Card/Card.prompt.md":"7567c932b6fd","components/data-display/CardBrand/CardBrand.jsx":"500d95f15656","components/data-display/CardBrand/CardBrand.d.ts":"3ccd8e552ce3","components/data-display/CardBrand/CardBrand.prompt.md":"f646df5a6dde","components/data-display/ChartCard/ChartCard.jsx":"5065083514aa","components/data-display/ChartCard/ChartCard.d.ts":"9ea01b91a448","components/data-display/ChartCard/ChartCard.prompt.md":"eb8e9a7fcb25","components/forms/Checkbox/Checkbox.jsx":"0d918ed227d0","components/forms/Checkbox/Checkbox.d.ts":"09a0eddabedd","components/forms/Checkbox/Checkbox.prompt.md":"9025697418d5","components/forms/ChoiceCard/ChoiceCard.jsx":"a5a4806aa90a","components/forms/ChoiceCard/ChoiceCard.d.ts":"45e3d8bcf504","components/forms/ChoiceCard/ChoiceCard.prompt.md":"29928be8d43c","components/forms/ChoiceCardGroup/ChoiceCardGroup.jsx":"36eeccaa8468","components/forms/ChoiceCardGroup/ChoiceCardGroup.d.ts":"902f2a50980b","components/forms/ChoiceCardGroup/ChoiceCardGroup.prompt.md":"abb7fb7a3e73","components/data-display/CodeBlock/CodeBlock.jsx":"2401705cd699","components/data-display/CodeBlock/CodeBlock.d.ts":"104ad214529c","components/data-display/CodeBlock/CodeBlock.prompt.md":"ad8fdd341012","components/forms/ColorInput/ColorInput.jsx":"81957723eaaa","components/forms/ColorInput/ColorInput.d.ts":"6a5895ecf279","components/forms/ColorInput/ColorInput.prompt.md":"d55fd4212880","components/data-display/CountTabs/CountTabs.jsx":"b32cc5d4643d","components/data-display/CountTabs/CountTabs.d.ts":"01ed4dd02ebb","components/data-display/CountTabs/CountTabs.prompt.md":"d78f829148b0","components/forms/DatePicker/DatePicker.jsx":"763508fa2c5c","components/forms/DatePicker/DatePicker.d.ts":"90636322ad0e","components/forms/DatePicker/DatePicker.prompt.md":"cad2157477c9","components/data-display/DetailsList/DetailsList.jsx":"bf01c93336f0","components/data-display/DetailsList/DetailsList.d.ts":"7399cbdfb00f","components/data-display/DetailsList/DetailsList.prompt.md":"9b8c4923b6f9","components/feedback/Drawer/Drawer.jsx":"8a51bc7b29a8","components/feedback/Drawer/Drawer.d.ts":"d4e8f0e11376","components/feedback/Drawer/Drawer.prompt.md":"4d3a8028b7a5","components/data-display/EmptyState/EmptyState.jsx":"fb8ffe7c400f","components/data-display/EmptyState/EmptyState.d.ts":"9328882168e8","components/data-display/EmptyState/EmptyState.prompt.md":"f079bcfd0696","components/forms/Field/Field.jsx":"eea3c96e23fa","components/forms/Field/Field.d.ts":"76039e289398","components/forms/Field/Field.prompt.md":"5324a0f2796b","components/forms/FilterChip/FilterChip.jsx":"1a4eb08eec26","components/forms/FilterChip/FilterChip.d.ts":"68b0378ba4c4","components/forms/FilterChip/FilterChip.prompt.md":"f67d9cffdcc3","components/navigation/FocusHeader/FocusHeader.jsx":"6a049b956538","components/navigation/FocusHeader/FocusHeader.d.ts":"0d0fc2e5ecb0","components/navigation/FocusHeader/FocusHeader.prompt.md":"d0e4bf59a6f1","components/actions/Hint/Hint.jsx":"967a51d4dfa5","components/actions/Hint/Hint.d.ts":"31dae3d6c1f2","components/actions/Hint/Hint.prompt.md":"a3cbda9d9ba1","components/foundations/Icon/Icon.jsx":"e00d9cd0d432","components/foundations/Icon/Icon.d.ts":"b90e601eb28e","components/foundations/Icon/Icon.prompt.md":"3c1b9782f078","components/data-display/IdChip/IdChip.jsx":"ab0727bcbf1b","components/data-display/IdChip/IdChip.d.ts":"648472120603","components/data-display/IdChip/IdChip.prompt.md":"cd3e7a6823ab","components/actions/Kbd/Kbd.jsx":"847991fb12f1","components/actions/Kbd/Kbd.d.ts":"8b589c9fdfdb","components/actions/Kbd/Kbd.prompt.md":"a9eb71651611","components/actions/Link/Link.jsx":"7387d4b03019","components/actions/Link/Link.d.ts":"dba4b08f62a6","components/actions/Link/Link.prompt.md":"bf51ec672b36","components/actions/Menu/Menu.jsx":"f70bc8b2ef31","components/actions/Menu/Menu.d.ts":"044d66f6ed21","components/actions/Menu/Menu.prompt.md":"4fb2b7c0fc01","components/actions/MenuItem/MenuItem.jsx":"c69c37225ac7","components/actions/MenuItem/MenuItem.d.ts":"d26a6cec62e1","components/actions/MenuItem/MenuItem.prompt.md":"3158fa4ebcb3","components/actions/MenuLabel/MenuLabel.jsx":"0a5c1b543d78","components/actions/MenuLabel/MenuLabel.d.ts":"89ccf88f802e","components/actions/MenuLabel/MenuLabel.prompt.md":"04f6e4976d2f","components/actions/MenuSeparator/MenuSeparator.jsx":"3a019961e3ec","components/actions/MenuSeparator/MenuSeparator.d.ts":"39304fa6677f","components/actions/MenuSeparator/MenuSeparator.prompt.md":"646f92f07f0a","components/data-display/Metric/Metric.jsx":"e9fae9e76652","components/data-display/Metric/Metric.d.ts":"206bf419b4f4","components/data-display/Metric/Metric.prompt.md":"5db2ecc01bba","components/feedback/Modal/Modal.jsx":"ae9b101b02ab","components/feedback/Modal/Modal.d.ts":"e64fdb2c1663","components/feedback/Modal/Modal.prompt.md":"079e98f6f5a9","components/forms/OTPInput/OTPInput.jsx":"71b178176ffb","components/forms/OTPInput/OTPInput.d.ts":"3bb2f35438ef","components/forms/OTPInput/OTPInput.prompt.md":"622bb54aeb5f","components/layout/PageHeader/PageHeader.jsx":"b4be14c2b68d","components/layout/PageHeader/PageHeader.d.ts":"c3dd38410802","components/layout/PageHeader/PageHeader.prompt.md":"9db9f56acd5d","components/navigation/Pagination/Pagination.jsx":"bde039665087","components/navigation/Pagination/Pagination.d.ts":"52e1b6c5d3ea","components/navigation/Pagination/Pagination.prompt.md":"da708e606229","components/forms/PasswordStrength/PasswordStrength.jsx":"c7b5c24c876e","components/forms/PasswordStrength/PasswordStrength.d.ts":"a3cbf552a733","components/forms/PasswordStrength/PasswordStrength.prompt.md":"4d4ca3eb7b23","components/actions/PlusButton/PlusButton.jsx":"f27942373dd6","components/actions/PlusButton/PlusButton.d.ts":"ab42514a6caf","components/actions/PlusButton/PlusButton.prompt.md":"e2b37a514606","components/forms/Radio/Radio.jsx":"9c7406239be2","components/forms/Radio/Radio.d.ts":"38bae5e36167","components/forms/Radio/Radio.prompt.md":"4269bff034b3","components/data-display/RequestLog/RequestLog.jsx":"631f294589df","components/data-display/RequestLog/RequestLog.d.ts":"44591c03f6ac","components/data-display/RequestLog/RequestLog.prompt.md":"8b2a41cf19e8","components/forms/SearchInput/SearchInput.jsx":"e93db12b1853","components/forms/SearchInput/SearchInput.d.ts":"85c2105dc45f","components/forms/SearchInput/SearchInput.prompt.md":"5c399b251c43","components/layout/SectionTitle/SectionTitle.jsx":"d17a745e9d8c","components/layout/SectionTitle/SectionTitle.d.ts":"c83c8eca34cb","components/layout/SectionTitle/SectionTitle.prompt.md":"7456864b4c62","components/forms/Select/Select.jsx":"5899bae0a745","components/forms/Select/Select.d.ts":"7163b7aa17fb","components/forms/Select/Select.prompt.md":"689f333b073e","components/navigation/Sidebar/Sidebar.jsx":"95f6746417f5","components/navigation/Sidebar/Sidebar.d.ts":"1172b30e4075","components/navigation/Sidebar/Sidebar.prompt.md":"5bfe2e92ece5","components/feedback/Spinner/Spinner.jsx":"9389694bbf1c","components/feedback/Spinner/Spinner.d.ts":"d610fdd90aec","components/feedback/Spinner/Spinner.prompt.md":"6515292ab136","components/navigation/Stepper/Stepper.jsx":"261930577114","components/navigation/Stepper/Stepper.d.ts":"3643e7a9dcb9","components/navigation/Stepper/Stepper.prompt.md":"617b0e65f533","components/forms/Switch/Switch.jsx":"75e29450c919","components/forms/Switch/Switch.d.ts":"da670bbe1268","components/forms/Switch/Switch.prompt.md":"d2c83289d385","components/data-display/Table/Table.jsx":"1f45f7f773f3","components/data-display/Table/Table.d.ts":"0273551c80b0","components/data-display/Table/Table.prompt.md":"56f710efba8d","components/navigation/Tabs/Tabs.jsx":"58a4e8db7eca","components/navigation/Tabs/Tabs.d.ts":"a06c2f85e649","components/navigation/Tabs/Tabs.prompt.md":"f675ba6a9226","components/data-display/Tag/Tag.jsx":"5a9868b24b89","components/data-display/Tag/Tag.d.ts":"ac8bde1c6659","components/data-display/Tag/Tag.prompt.md":"11f591c75b12","components/feedback/TestModeBar/TestModeBar.jsx":"7c395c522bb4","components/feedback/TestModeBar/TestModeBar.d.ts":"59ce503028eb","components/feedback/TestModeBar/TestModeBar.prompt.md":"0be588d244e6","components/forms/Textarea/Textarea.jsx":"e8f56bdaf6bd","components/forms/Textarea/Textarea.d.ts":"86d3025cc836","components/forms/Textarea/Textarea.prompt.md":"7a66ab7cee6c","components/forms/TextInput/TextInput.jsx":"710280af93d3","components/forms/TextInput/TextInput.d.ts":"b3e8b8e56e8c","components/forms/TextInput/TextInput.prompt.md":"d0410ae034aa","components/data-display/Timeline/Timeline.jsx":"4bc3b29d9b50","components/data-display/Timeline/Timeline.d.ts":"d1c8ab71cbb5","components/data-display/Timeline/Timeline.prompt.md":"b7f0e23162ac","components/feedback/Toast/Toast.jsx":"37a59874955c","components/feedback/Toast/Toast.d.ts":"52c7dc0eac41","components/feedback/Toast/Toast.prompt.md":"35b4c694193f","components/feedback/Tooltip/Tooltip.jsx":"af4ee465c000","components/feedback/Tooltip/Tooltip.d.ts":"928afa5e41ba","components/feedback/Tooltip/Tooltip.prompt.md":"3988f7a59ddc","components/navigation/TopBar/TopBar.jsx":"5ebd2bf094e6","components/navigation/TopBar/TopBar.d.ts":"061b54526e60","components/navigation/TopBar/TopBar.prompt.md":"100a437d3af9","components/feedback/TourPopover/TourPopover.jsx":"d9d7e9b5f882","components/feedback/TourPopover/TourPopover.d.ts":"1bc21b4cbc01","components/feedback/TourPopover/TourPopover.prompt.md":"a36d1f2d2bea"},"inlinedExternals":[],"builtBy":"cc-design-sync"} */
"use strict";
var StripeDashboard = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx58(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs48(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx58;
      module.exports.jsxs = jsxs48;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs48 : jsx58)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // dist/index.js
  var index_exports = {};
  __export(index_exports, {
    Amount: () => Amount,
    AppShell: () => AppShell,
    AuthLayout: () => AuthLayout,
    Badge: () => Badge,
    Banner: () => Banner,
    Breadcrumb: () => Breadcrumb,
    BreakdownBar: () => BreakdownBar,
    BreakdownList: () => BreakdownList,
    Button: () => Button,
    Card: () => Card,
    CardBrand: () => CardBrand,
    ChartCard: () => ChartCard,
    Checkbox: () => Checkbox,
    ChoiceCard: () => ChoiceCard,
    ChoiceCardGroup: () => ChoiceCardGroup,
    CodeBlock: () => CodeBlock,
    ColorInput: () => ColorInput,
    CountTabs: () => CountTabs,
    DatePicker: () => DatePicker,
    DetailsList: () => DetailsList,
    Drawer: () => Drawer,
    EmptyState: () => EmptyState,
    Field: () => Field,
    FilterChip: () => FilterChip,
    FocusHeader: () => FocusHeader,
    Hint: () => Hint,
    Icon: () => Icon,
    IdChip: () => IdChip,
    Kbd: () => Kbd,
    Link: () => Link,
    Menu: () => Menu,
    MenuItem: () => MenuItem,
    MenuLabel: () => MenuLabel,
    MenuSeparator: () => MenuSeparator,
    Metric: () => Metric,
    Modal: () => Modal,
    OTPInput: () => OTPInput,
    PageHeader: () => PageHeader,
    Pagination: () => Pagination,
    PasswordStrength: () => PasswordStrength,
    PlusButton: () => PlusButton,
    Radio: () => Radio,
    RequestLog: () => RequestLog,
    SearchInput: () => SearchInput,
    SectionTitle: () => SectionTitle,
    Select: () => Select,
    Sidebar: () => Sidebar,
    Spinner: () => Spinner,
    Stepper: () => Stepper,
    Switch: () => Switch,
    Table: () => Table,
    Tabs: () => Tabs,
    Tag: () => Tag,
    TestModeBar: () => TestModeBar,
    TextInput: () => TextInput,
    Textarea: () => Textarea,
    Timeline: () => Timeline,
    Toast: () => Toast,
    Tooltip: () => Tooltip,
    TopBar: () => TopBar,
    TourPopover: () => TourPopover
  });
  init_define_import_meta_env();
  var import_jsx_runtime = __toESM(require_react_shim(), 1);
  var import_jsx_runtime2 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime3 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime4 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime5 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime6 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime7 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime8 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime9 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime10 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime11 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime12 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime13 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime14 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime15 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime16 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime17 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime18 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime19 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime20 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime21 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime22 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime23 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime24 = __toESM(require_react_shim(), 1);
  var React = __toESM(require_react_shim(), 1);
  var import_jsx_runtime25 = __toESM(require_react_shim(), 1);
  var React2 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime26 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime27 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime28 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime29 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime30 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime31 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime32 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime33 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime34 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime35 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime36 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime37 = __toESM(require_react_shim(), 1);
  var React3 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime38 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime39 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime40 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime41 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime42 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime43 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime44 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime45 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime46 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime47 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime48 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime49 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime50 = __toESM(require_react_shim(), 1);
  var React4 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime51 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime52 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime53 = __toESM(require_react_shim(), 1);
  var React5 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime54 = __toESM(require_react_shim(), 1);
  var React6 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime55 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime56 = __toESM(require_react_shim(), 1);
  var import_jsx_runtime57 = __toESM(require_react_shim(), 1);
  function cx(...parts) {
    return parts.filter(Boolean).join(" ");
  }
  var PATHS = {
    "home": "M2.5 7 8 2.5 13.5 7v6.5h-4V10h-3v3.5h-4Z",
    "balances": "M2.5 4h8M2.5 8h5M2.5 12h4M11.5 9.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z",
    "transactions": "M2.5 5.5h10l-2.5-2.5M13.5 10.5h-10l2.5 2.5",
    "customers": "M8 2.5a2.75 2.75 0 1 0 0 5.5 2.75 2.75 0 0 0 0-5.5ZM3 13.5c.6-2.3 2.6-3.5 5-3.5s4.4 1.2 5 3.5",
    "product": "M8 1.8 13.5 5v6L8 14.2 2.5 11V5ZM2.5 5 8 8.2 13.5 5M8 8.2v6",
    "payments": "M2.5 4.5h9.5v2M2.5 4.5v8h11v-6h-11M10.5 9.5h1",
    "billing": "M4 1.8h6l2.5 2.5v9.9H4ZM6 6.5h4M6 9h4M6 11.5h2",
    "reporting": "M2.5 2.5v11h11M5.5 11V8M8.5 11V5M11.5 11V7",
    "more": "M3.5 8h.01M8 8h.01M12.5 8h.01",
    "search": "M7 2.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9ZM10.3 10.3l3.2 3.2",
    "plus": "M8 3v10M3 8h10",
    "plus-circle": "M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8ZM8 5.5v5M5.5 8h5",
    "check": "M3 8.5 6.2 11.5 13 4.5",
    "check-circle": "M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8ZM5.3 8.2l1.8 1.8 3.6-3.8",
    "x": "M4 4l8 8M12 4l-8 8",
    "x-circle": "M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8ZM6 6l4 4M10 6l-4 4",
    "chev-down": "M4 6l4 4 4-4",
    "chev-right": "M6 4l4 4-4 4",
    "chev-left": "M10 4 6 8l4 4",
    "arrow-right": "M3 8h10M9.5 4.5 13 8l-3.5 3.5",
    "info": "M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8ZM8 7.3v3.7M8 5.2h.01",
    "bell": "M4 11.5V7a4 4 0 1 1 8 0v4.5l1 1H3ZM6.8 14h2.4",
    "gear": "M8 5.8a2.2 2.2 0 1 0 0 4.4 2.2 2.2 0 0 0 0-4.4ZM8 1.5v1.7M8 12.8v1.7M1.5 8h1.7M12.8 8h1.7M3.4 3.4l1.2 1.2M11.4 11.4l1.2 1.2M3.4 12.6l1.2-1.2M11.4 4.6l1.2-1.2",
    "help": "M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8ZM6.3 6.2a1.8 1.8 0 1 1 2.5 1.7c-.5.2-.8.6-.8 1.1v.4M8 11.3h.01",
    "grid": "M2.5 2.5h4v4h-4ZM9.5 2.5h4v4h-4ZM2.5 9.5h4v4h-4ZM9.5 9.5h4v4h-4Z",
    "calendar": "M2.5 3.5h11v10h-11ZM2.5 6.5h11M5.5 2v3M10.5 2v3",
    "clock": "M8 1.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 8 1.8ZM8 4.5V8l2.5 1.5",
    "copy": "M5.5 5.5h8v8h-8ZM10.5 5.5v-3h-8v8h3",
    "external": "M9.5 2.5h4v4M13.5 2.5 7.5 8.5M11.5 9.5v4h-9v-9h4",
    "export": "M8 2.5v7M5 5.5l3-3 3 3M3 9.5v4h10v-4",
    "edit": "M10.5 2.5l3 3-8 8h-3v-3Z",
    "bulb": "M6 12.5h4M6.5 14.5h3M8 1.5a4.5 4.5 0 0 0-2.5 8.2V11h5V9.7A4.5 4.5 0 0 0 8 1.5Z",
    "alert": "M8 2 14.5 13.5h-13ZM8 6.5v3M8 11.5h.01",
    "lock": "M3.5 7.5h9v6.5h-9ZM5.5 7.5V5a2.5 2.5 0 0 1 5 0v2.5",
    "refund": "M5.5 3.5 2.5 6.5l3 3M2.5 6.5h7a4 4 0 0 1 0 8h-2",
    "columns": "M2.5 2.5h11v11h-11ZM6.2 2.5v11M9.8 2.5v11",
    "dollar": "M2.5 4h11v8h-11ZM8 6.2a1.8 1.8 0 1 0 0 3.6 1.8 1.8 0 0 0 0-3.6Z",
    "doc": "M4 1.8h5.5l3 3v9.4H4ZM9.5 1.8v3h3",
    "code": "M5.5 4.5 2 8l3.5 3.5M10.5 4.5 14 8l-3.5 3.5",
    "dots": "M3.5 8h.01M8 8h.01M12.5 8h.01",
    "bag": "M3 5h10l-.8 9H3.8ZM5.5 5a2.5 2.5 0 0 1 5 0",
    "eye": "M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8ZM8 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"
  };
  function Icon({ name, size = "md", label, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "svg",
      {
        className: cx("sd-icon", size === "sm" && "sd-icon--sm", className),
        viewBox: "0 0 16 16",
        role: label ? "img" : void 0,
        "aria-label": label,
        "aria-hidden": label ? void 0 : true,
        ...rest,
        children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: PATHS[name] })
      }
    );
  }
  function Kbd({ className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: cx("sd-kbd", className), ...rest });
  }
  function Button({ variant = "secondary", size = "md", icon, iconEnd, shortcut, block, className, children, type = "button", ...rest }) {
    const iconOnly = icon && (children === void 0 || children === null);
    return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(
      "button",
      {
        type,
        className: cx(
          "sd-btn",
          variant !== "secondary" && `sd-btn--${variant}`,
          size !== "md" && `sd-btn--${size}`,
          iconOnly && "sd-btn--icon",
          block && "sd-btn--block",
          className
        ),
        ...rest,
        children: [
          icon && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Icon, { name: icon }),
          children,
          iconEnd && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Icon, { name: iconEnd }),
          shortcut && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Kbd, { children: shortcut })
        ]
      }
    );
  }
  function Hint({ className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { tabIndex: 0, className: cx("sd-hint", className), ...rest });
  }
  function Link({ external, arrow, className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("a", { className: cx("sd-link", className), ...rest, children: [
      children,
      external && /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
        "\xA0",
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(Icon, { name: "external" })
      ] }),
      arrow && /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
        "\xA0",
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(Icon, { name: "arrow-right" })
      ] })
    ] });
  }
  function Menu({ className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { role: "menu", className: cx("sd-menu", className), ...rest });
  }
  function MenuItem({ tone = "action", icon, shortcut, className, children, type = "button", ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("button", { type, role: "menuitem", className: cx("sd-menu__item", tone !== "action" && `sd-menu__item--${tone}`, className), ...rest, children: [
      icon && /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(Icon, { name: icon }),
      children,
      shortcut && /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(Kbd, { children: shortcut })
    ] });
  }
  function MenuLabel({ className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: cx("sd-menu__label", className), ...rest });
  }
  function MenuSeparator({ className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { role: "separator", className: cx("sd-menu__sep", className), ...rest });
  }
  function PlusButton({ className, type = "button", ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("button", { type, "aria-label": "Create", className: cx("sd-btn-plus", className), ...rest, children: /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Icon, { name: "plus" }) });
  }
  function Amount({ value, currency, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("span", { className, ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "sd-amount", style: { fontWeight: 600, color: "var(--text)" }, children: value }),
      currency && /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: cx("sd-cur"), style: { color: "var(--text-subdued)", marginLeft: 4 }, children: currency })
    ] });
  }
  function Badge({ tone = "neutral", icon, className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("span", { className: cx("sd-badge", tone !== "neutral" && `sd-badge--${tone}`, className), ...rest, children: [
      children,
      icon && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icon, { name: icon })
    ] });
  }
  function BreakdownBar({ segments, className, ...rest }) {
    const total = segments.reduce((s, x) => s + x.value, 0) || 1;
    return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: cx("sd-stack", className), style: { gap: 12 }, ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "sd-bar", role: "img", "aria-label": segments.map((s) => `${s.label} ${s.display}`).join(", "), children: segments.filter((s) => s.value > 0).map((s) => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { style: { width: `${s.value / total * 100}%`, background: `var(--${s.color})` } }, s.label)) }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "sd-legend", children: segments.map((s) => /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "sd-legend__row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "sd-legend__key", children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "sd-legend__sw", style: { background: `var(--${s.color})` } }),
          s.label
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: s.display })
      ] }, s.label)) })
    ] });
  }
  function BreakdownList({ items, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: cx("sd-breakdown", className), ...rest, children: items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("span", { children: it.label }),
      /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("span", { children: it.value })
    ] }, i)) });
  }
  function CardBrand({ brand = "VISA", last4, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("span", { ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("span", { className: "sd-card-brand", children: brand }),
      last4 && `\u2022\u2022\u2022\u2022 ${last4}`
    ] });
  }
  function Metric({ label, value, compare, delta, deltaTone = "success", info, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: cx("sd-metric", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("span", { className: "sd-metric__label", children: [
        label,
        info && /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Icon, { name: "info" }),
        delta && /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Badge, { tone: deltaTone, children: delta })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("span", { className: "sd-metric__value", children: value }),
      compare && /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("span", { className: "sd-metric__compare", children: compare })
    ] });
  }
  function ChartCard({ data, previous, startLabel, endLabel, maxLabel, updated, moreLabel = "View more", moreHref, className, ...metric }) {
    const W = 300, H = 110, top = 12, bottom = 90;
    const max = Math.max(1, ...data, ...previous ?? []);
    const pts = (s) => s.map((v, i) => `${i / Math.max(1, s.length - 1) * W},${bottom - v / max * (bottom - top)}`).join(" ");
    const peak = data.indexOf(Math.max(...data));
    return /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: cx("sd-chart", className), children: [
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Metric, { ...metric }),
      /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": typeof metric.label === "string" ? `${metric.label} chart` : "Chart", children: [
        /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("line", { className: "sd-chart__grid", x1: "0", y1: top - 2, x2: W, y2: top - 2 }),
        /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("line", { className: "sd-chart__grid", x1: "0", y1: bottom, x2: W, y2: bottom }),
        maxLabel && /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("text", { className: "sd-chart__axis", x: "0", y: "6", children: maxLabel }),
        previous && /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("polyline", { className: "sd-chart__prev", points: pts(previous) }),
        /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("polyline", { className: "sd-chart__line", points: pts(data) }),
        data.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("circle", { className: "sd-chart__dot", cx: peak / Math.max(1, data.length - 1) * W, cy: bottom - data[peak] / max * (bottom - top), r: "3" }),
        startLabel && /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("text", { className: "sd-chart__axis", x: "0", y: H - 4, children: startLabel }),
        endLabel && /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("text", { className: "sd-chart__axis", x: W, y: H - 4, textAnchor: "end", children: endLabel })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: "sd-chart__foot", children: [
        /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("a", { className: "sd-link", href: moreHref, children: moreLabel }),
        updated && /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("span", { children: updated })
      ] })
    ] });
  }
  function highlight(src) {
    const out = [];
    const rx = /("(?:[^"\\]|\\.)*")(\s*:)?|\b(true|false|null|-?\d+(?:\.\d+)?)\b/g;
    let last = 0;
    let m;
    let i = 0;
    while (m = rx.exec(src)) {
      out.push(src.slice(last, m.index));
      if (m[1]) out.push(/* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: m[2] ? "k" : "s", children: m[1] }, i++), m[2] ?? "");
      else out.push(/* @__PURE__ */ (0, import_jsx_runtime15.jsx)("span", { className: "n", children: m[3] }, i++));
      last = rx.lastIndex;
    }
    out.push(src.slice(last));
    return out;
  }
  function CodeBlock({ json, code, className, ...rest }) {
    const text = json !== void 0 ? JSON.stringify(json, null, 2) : code ?? "";
    return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("pre", { className: cx("sd-code", className), ...rest, children: json !== void 0 ? highlight(text) : text });
  }
  function CountTabs({ items, value, onChange, className, ...rest }) {
    const current = value ?? items[0]?.value ?? items[0]?.label;
    return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("div", { role: "tablist", className: cx("sd-counts", className), ...rest, children: items.map((t) => {
      const v = t.value ?? t.label;
      return /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("button", { type: "button", role: "tab", "aria-selected": v === current, className: "sd-count", onClick: () => onChange?.(v), children: [
        t.label,
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("span", { className: "sd-count__n", children: t.count })
      ] }, v);
    }) });
  }
  function DetailsList({ items, layout = "stacked", className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("dl", { className: cx("sd-details", layout === "rows" && "sd-details--rows", className), ...rest, children: items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("dt", { children: it.label }),
      /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("dd", { children: it.value === void 0 || it.value === null || it.value === "" ? /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("span", { style: { color: "var(--text-placeholder)" }, children: "\u2014" }) : it.value })
    ] }, i)) });
  }
  function EmptyState({ icon, title, description, action, boxed, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime18.jsxs)("div", { className: cx("sd-empty", boxed && "sd-empty--boxed", className), ...rest, children: [
      icon && /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("span", { className: "sd-empty__icon", children: /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(Icon, { name: icon }) }),
      title && /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("span", { className: "sd-empty__title", children: title }),
      description && /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("span", { className: "sd-empty__desc", children: description }),
      action
    ] });
  }
  function IdChip({ value, href, copyable = !href, className, ...rest }) {
    if (href) return /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("a", { href, className: cx("sd-id sd-id--link", className), ...rest, children: value });
    return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("span", { className: cx("sd-id", className), ...rest, children: [
      value,
      copyable && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", "aria-label": "Copy", onClick: () => navigator.clipboard?.writeText(value).catch(() => {
      }), children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Icon, { name: "copy" }) })
    ] });
  }
  function RequestLog({ entries, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("div", { className: cx("sd-log", className), ...rest, children: entries.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)(Badge, { tone: e.status < 300 ? "success" : e.status < 500 ? "warning" : "danger", children: [
        e.status,
        " ",
        e.status < 300 ? "OK" : "ERR"
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime20.jsxs)("span", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("span", { style: e.method === "DELETE" ? { color: "var(--red-700)", fontWeight: 600 } : void 0, children: e.method }),
        " ",
        e.path
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("time", { children: e.time })
    ] }, i)) });
  }
  function Table({ columns, rows, rowKey, selectable, selectedKeys = [], onToggleRow, rowActions, onRowClick, footer, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("div", { className, ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("div", { className: "sd-table-wrap", children: /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("table", { className: "sd-table", children: [
        /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("tr", { children: [
          selectable && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("th", { style: { width: 28 }, children: /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("label", { className: "sd-check", children: /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("input", { type: "checkbox", "aria-label": "Select all" }) }) }),
          columns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("th", { className: c.align === "end" ? "sd-num" : void 0, style: c.width ? { width: c.width } : void 0, children: c.header }, c.key)),
          rowActions && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("th", {})
        ] }) }),
        /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("tbody", { children: rows.map((r, i) => {
          const k = rowKey(r, i);
          const sel = selectedKeys.includes(k);
          return /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("tr", { "aria-selected": sel || void 0, onClick: onRowClick ? () => onRowClick(r) : void 0, style: onRowClick ? { cursor: "pointer" } : void 0, children: [
            selectable && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("label", { className: "sd-check", children: /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("input", { type: "checkbox", "aria-label": "Select row", checked: sel, onChange: () => onToggleRow?.(k) }) }) }),
            columns.map((c) => {
              const v = c.render ? c.render(r) : r[c.key];
              return /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("td", { className: cx(c.align === "end" && "sd-num"), children: v === void 0 || v === null || v === "" ? /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("span", { className: "sd-dash", children: "\u2014" }) : v }, c.key);
            }),
            rowActions && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("td", { className: "sd-actions", children: /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(Icon, { name: "dots", label: "Row actions" }) })
          ] }, k);
        }) })
      ] }) }),
      footer && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("div", { className: "sd-table-foot", children: footer })
    ] });
  }
  function Tag({ tone = "neutral", className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("span", { className: cx("sd-tag", tone !== "neutral" && `sd-tag--${tone}`, className), ...rest });
  }
  function Timeline({ items, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("ol", { className: cx("sd-timeline", className), ...rest, children: items.map((it, i) => {
      const tone = it.tone ?? "neutral";
      const icon = tone === "success" ? "check-circle" : tone === "danger" ? "x-circle" : it.icon ?? "dollar";
      return /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("li", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("span", { className: cx("sd-timeline__node", tone !== "neutral" && `sd-timeline__node--${tone}`), children: /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(Icon, { name: icon }) }),
        /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("div", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "sd-timeline__title", children: it.title }),
          it.time && /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "sd-timeline__time", children: it.time }),
          it.children
        ] })
      ] }, i);
    }) });
  }
  var DEFAULT_ICON = { neutral: "bulb", critical: "alert", warning: "clock", success: "check-circle", navy: "transactions" };
  function Banner({ tone = "neutral", icon, title, actions, onDismiss, className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { role: tone === "critical" ? "alert" : "status", className: cx("sd-banner", tone !== "neutral" && `sd-banner--${tone}`, className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(Icon, { name: icon ?? DEFAULT_ICON[tone] }),
      /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "sd-banner__body", children: [
        title && /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("div", { className: "sd-banner__title", children: title }),
        children && /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("div", { children })
      ] }),
      (actions || onDismiss) && /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "sd-banner__actions", children: [
        actions,
        onDismiss && /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("button", { type: "button", className: "sd-banner__close", "aria-label": "Dismiss", onClick: onDismiss, children: /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(Icon, { name: "x" }) })
      ] })
    ] });
  }
  function Drawer({ open = true, title, eyebrow, onClose, footerStart, footer, width = 440, inline, className, children, ...rest }) {
    const id = React.useId();
    if (!open) return null;
    return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: cx("sd-drawer-scrim", !inline && "sd-drawer-scrim--fixed"), onClick: (e) => e.target === e.currentTarget && onClose?.(), children: /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("aside", { role: "dialog", "aria-modal": "true", "aria-labelledby": id, className: cx("sd-drawer", className), style: { width: `min(100%, ${width}px)` }, ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "sd-drawer__head", children: [
        /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { children: [
          eyebrow && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "sd-drawer__eyebrow", children: eyebrow }),
          /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("h2", { className: "sd-modal__title", id, children: title })
        ] }),
        onClose && /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("button", { type: "button", className: "sd-close", "aria-label": "Close", onClick: onClose, children: /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(Icon, { name: "x" }) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: "sd-drawer__body", children }),
      (footer || footerStart) && /* @__PURE__ */ (0, import_jsx_runtime25.jsxs)("div", { className: "sd-drawer__foot", children: [
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { children: footerStart }),
        /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("span", { className: "sd-row", children: footer })
      ] })
    ] }) });
  }
  function Modal({ open = true, title, onClose, footer, width = 480, inline, className, children, ...rest }) {
    React2.useEffect(() => {
      if (!open || !onClose) return;
      const h = (e) => e.key === "Escape" && onClose();
      window.addEventListener("keydown", h);
      return () => window.removeEventListener("keydown", h);
    }, [open, onClose]);
    const id = React2.useId();
    if (!open) return null;
    return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", { className: cx("sd-scrim", !inline && "sd-scrim--fixed"), onClick: (e) => e.target === e.currentTarget && onClose?.(), children: /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { role: "dialog", "aria-modal": "true", "aria-labelledby": id, className: cx("sd-modal", className), style: { width: `min(100%, ${width}px)` }, ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "sd-modal__head", children: [
        /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("h2", { className: "sd-modal__title", id, children: title }),
        onClose && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("button", { type: "button", className: "sd-close", "aria-label": "Close", onClick: onClose, children: /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(Icon, { name: "x" }) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", { className: "sd-modal__body", children }),
      footer && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("div", { className: "sd-modal__foot", children: footer })
    ] }) });
  }
  function Spinner({ size = "sm", label = "Loading", className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("span", { role: "status", "aria-label": label, className: cx("sd-spinner", size === "lg" && "sd-spinner--lg", className), ...rest });
  }
  function TestModeBar({ children = "You're using test data. To accept payments, complete your business profile.", action, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: cx("sd-testbar", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("span", { className: "sd-testbar__tag", children: "Test mode" }),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("span", { children }),
      action
    ] });
  }
  function Toast({ children, actionLabel, onAction, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("div", { role: "status", className: cx("sd-toast", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icon, { name: "check-circle" }),
      children,
      actionLabel && /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("button", { type: "button", className: "sd-toast__action", onClick: onAction, children: actionLabel })
    ] });
  }
  function Tooltip({ children, shortcut, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime30.jsxs)("span", { role: "tooltip", className: cx("sd-tooltip", className), ...rest, children: [
      children,
      shortcut && /* @__PURE__ */ (0, import_jsx_runtime30.jsx)(Kbd, { children: shortcut })
    ] });
  }
  function TourPopover({ children, nextLabel = "Next", onNext, onSkip, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime31.jsxs)("div", { role: "dialog", "aria-label": "Tour step", className: cx("sd-tour", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { children }),
      /* @__PURE__ */ (0, import_jsx_runtime31.jsxs)("div", { className: "sd-tour__foot", children: [
        /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("a", { className: "sd-tour__skip", role: "button", tabIndex: 0, onClick: onSkip, children: "Skip tour" }),
        /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("button", { type: "button", className: "sd-btn sd-btn--sm", onClick: onNext, children: nextLabel })
      ] })
    ] });
  }
  function Checkbox({ label, description, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)("label", { className: cx("sd-check", className), children: [
      /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("input", { type: "checkbox", "aria-label": label ? void 0 : rest["aria-label"], ...rest }),
      description ? /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)("span", { className: "sd-check__text", children: [
        /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("span", { className: "sd-check__title", children: label }),
        /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("span", { className: "sd-check__desc", children: description })
      ] }) : label ? /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("span", { children: label }) : null
    ] });
  }
  function ChoiceCard({ title, description, eyebrow, selected, align = "start", className, type = "button", ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime33.jsxs)("button", { type, role: "radio", "aria-checked": !!selected, className: cx("sd-choice", align === "center" && "sd-choice--center", className), ...rest, children: [
      eyebrow && /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("span", { className: "sd-choice__desc", children: eyebrow }),
      /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("span", { className: "sd-choice__title", children: title }),
      description && /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("span", { className: "sd-choice__desc", children: description })
    ] });
  }
  function ChoiceCardGroup({ className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("div", { role: "radiogroup", className: cx("sd-choices", className), ...rest });
  }
  function ColorInput({ label, value, onChange, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime34.jsxs)("div", { className: cx("sd-color", className), children: [
      /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("span", { className: "sd-swatch", style: { background: value } }),
      label && /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("span", { style: { flex: 1 }, children: label }),
      /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(
        "input",
        {
          className: "sd-input",
          value,
          "aria-label": typeof label === "string" ? label : "Colour",
          onChange: (e) => onChange?.(e.target.value),
          readOnly: !onChange,
          ...rest
        }
      )
    ] });
  }
  var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  var pad = (n) => String(n).padStart(2, "0");
  function DatePicker({ month, value, min, onSelect, onMonthChange, shortcuts, onShortcut, className, ...rest }) {
    const [y, m] = (month ?? (value ? value.slice(0, 7) : "2024-12")).split("-").map(Number);
    const first = new Date(y, m - 1, 1);
    const lead = (first.getDay() + 6) % 7;
    const days = new Date(y, m, 0).getDate();
    const prevDays = new Date(y, m - 1, 0).getDate();
    const cells = [];
    for (let i = lead; i > 0; i--) cells.push({ d: prevDays - i + 1 });
    for (let d = 1; d <= days; d++) cells.push({ d, iso: `${y}-${pad(m)}-${pad(d)}` });
    while (cells.length % 7) cells.push({ d: cells.length - lead - days + 1 });
    const shift = (k) => {
      const t = new Date(y, m - 1 + k, 1);
      onMonthChange?.(`${t.getFullYear()}-${pad(t.getMonth() + 1)}`);
    };
    return /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("div", { className: cx("sd-datepicker", className), style: shortcuts ? void 0 : { gridTemplateColumns: "auto" }, ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("div", { className: "sd-cal", children: [
        /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("div", { className: "sd-cal__head", children: [
          /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("button", { type: "button", "aria-label": "Previous month", onClick: () => shift(-1), children: /* @__PURE__ */ (0, import_jsx_runtime35.jsx)(Icon, { name: "chev-left" }) }),
          MONTHS[m - 1],
          " ",
          y,
          /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("button", { type: "button", "aria-label": "Next month", onClick: () => shift(1), children: /* @__PURE__ */ (0, import_jsx_runtime35.jsx)(Icon, { name: "chev-right" }) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("div", { className: "sd-cal__grid", role: "grid", children: [
          ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("span", { className: "sd-cal__dow", children: d }, d)),
          cells.map((c, i) => {
            const off = !c.iso || min !== void 0 && c.iso < min;
            return /* @__PURE__ */ (0, import_jsx_runtime35.jsx)(
              "span",
              {
                role: "gridcell",
                "aria-selected": c.iso === value || void 0,
                className: cx("sd-cal__day", off && "sd-cal__day--off", c.iso === value && "sd-cal__day--sel"),
                onClick: () => !off && c.iso && onSelect?.(c.iso),
                children: c.d
              },
              i
            );
          })
        ] })
      ] }),
      shortcuts && /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("div", { className: "sd-cal__shortcuts", children: [
        /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("b", { children: "Shortcuts" }),
        shortcuts.map((s) => /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("a", { className: "sd-link", onClick: () => onShortcut?.(s), children: s }, s))
      ] })
    ] });
  }
  function Field({ label, htmlFor, optional, help, error, className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("div", { className: cx("sd-field", className), ...rest, children: [
      label && /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("label", { className: "sd-label", htmlFor, children: [
        label,
        optional && /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(Tag, { children: "Optional" })
      ] }),
      children,
      error ? /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("span", { className: "sd-error", role: "alert", children: [
        /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(Icon, { name: "alert" }),
        error
      ] }) : help ? /* @__PURE__ */ (0, import_jsx_runtime36.jsx)("span", { className: "sd-help", children: help }) : null
    ] });
  }
  function FilterChip({ label, value, className, type = "button", ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)("button", { type, className: cx("sd-filter", value && "sd-filter--applied", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(Icon, { name: value ? "x-circle" : "plus-circle" }),
      label,
      value && /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)(import_jsx_runtime37.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("span", { className: "sd-filter__sep" }),
        /* @__PURE__ */ (0, import_jsx_runtime37.jsx)("span", { className: "sd-filter__value", children: value }),
        /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(Icon, { name: "chev-down", size: "sm" })
      ] })
    ] });
  }
  function OTPInput({ value = "", onChange, disabled, className, ...rest }) {
    const refs = React3.useRef([]);
    const digits = Array.from({ length: 6 }, (_, i) => value[i] ?? "");
    const set = (i, d) => {
      const next = digits.slice();
      next[i] = d.replace(/\D/g, "").slice(-1);
      onChange?.(next.join(""));
      if (next[i] && i < 5) refs.current[i + 1]?.focus();
    };
    const box = (i) => /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(
      "input",
      {
        ref: (el) => {
          refs.current[i] = el;
        },
        inputMode: "numeric",
        maxLength: 1,
        "aria-label": `Digit ${i + 1}`,
        value: digits[i],
        disabled,
        onChange: (e) => set(i, e.target.value),
        readOnly: !onChange
      },
      i
    );
    return /* @__PURE__ */ (0, import_jsx_runtime38.jsxs)("div", { className: cx("sd-otp", className), "aria-label": "Verification code", ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime38.jsx)("div", { className: "sd-otp__group", children: [0, 1, 2].map(box) }),
      /* @__PURE__ */ (0, import_jsx_runtime38.jsx)("span", { className: "sd-otp__dash" }),
      /* @__PURE__ */ (0, import_jsx_runtime38.jsx)("div", { className: "sd-otp__group", children: [3, 4, 5].map(box) })
    ] });
  }
  function PasswordStrength({ level, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime39.jsx)("div", { className: cx("sd-strength", className), role: "meter", "aria-valuemin": 0, "aria-valuemax": 4, "aria-valuenow": level, "aria-label": "Password strength", ...rest, children: [0, 1, 2, 3].map((i) => /* @__PURE__ */ (0, import_jsx_runtime39.jsx)("span", { style: i < level ? { background: "var(--green-500)" } : void 0 }, i)) });
  }
  function Radio({ label, description, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime40.jsxs)("label", { className: cx("sd-check", className), children: [
      /* @__PURE__ */ (0, import_jsx_runtime40.jsx)("input", { type: "radio", "aria-label": label ? void 0 : rest["aria-label"], ...rest }),
      description ? /* @__PURE__ */ (0, import_jsx_runtime40.jsxs)("span", { className: "sd-check__text", children: [
        /* @__PURE__ */ (0, import_jsx_runtime40.jsx)("span", { className: "sd-check__title", children: label }),
        /* @__PURE__ */ (0, import_jsx_runtime40.jsx)("span", { className: "sd-check__desc", children: description })
      ] }) : label ? /* @__PURE__ */ (0, import_jsx_runtime40.jsx)("span", { children: label }) : null
    ] });
  }
  function SearchInput({ className, placeholder = "Search", ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime41.jsxs)("label", { className: cx("sd-search", className), children: [
      /* @__PURE__ */ (0, import_jsx_runtime41.jsx)(Icon, { name: "search" }),
      /* @__PURE__ */ (0, import_jsx_runtime41.jsx)("input", { type: "search", placeholder, "aria-label": rest["aria-label"] ?? placeholder, ...rest })
    ] });
  }
  function Select({ options, placeholder, className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime42.jsxs)("select", { className: cx("sd-select", className), defaultValue: placeholder && rest.value === void 0 && rest.defaultValue === void 0 ? "" : void 0, ...rest, children: [
      placeholder && /* @__PURE__ */ (0, import_jsx_runtime42.jsx)("option", { value: "", disabled: true, children: placeholder }),
      options?.map(
        (o) => typeof o === "string" ? /* @__PURE__ */ (0, import_jsx_runtime42.jsx)("option", { value: o, children: o }, o) : /* @__PURE__ */ (0, import_jsx_runtime42.jsx)("option", { value: o.value, disabled: o.disabled, children: o.label }, o.value)
      ),
      children
    ] });
  }
  function Switch({ label, labelPosition = "end", tone = "brand", className, ...rest }) {
    const input = /* @__PURE__ */ (0, import_jsx_runtime43.jsx)("input", { type: "checkbox", role: "switch", ...rest });
    return /* @__PURE__ */ (0, import_jsx_runtime43.jsxs)("label", { className: cx("sd-switch", tone === "testmode" && "sd-switch--testmode", className), children: [
      labelPosition === "start" && label,
      input,
      labelPosition === "end" && label
    ] });
  }
  function TextInput({ size = "md", prefix, suffix, invalid, className, ...rest }) {
    const input = /* @__PURE__ */ (0, import_jsx_runtime44.jsx)(
      "input",
      {
        className: cx("sd-input", size === "lg" && "sd-input--lg", !(prefix || suffix) && className),
        "aria-invalid": invalid || void 0,
        ...rest
      }
    );
    if (!prefix && !suffix) return input;
    return /* @__PURE__ */ (0, import_jsx_runtime44.jsxs)("div", { className: cx("sd-input-group", className), children: [
      prefix && /* @__PURE__ */ (0, import_jsx_runtime44.jsx)("span", { className: "sd-affix", children: prefix }),
      input,
      typeof suffix === "string" ? /* @__PURE__ */ (0, import_jsx_runtime44.jsx)("span", { className: "sd-affix", style: { paddingRight: 8 }, children: suffix }) : suffix
    ] });
  }
  function Textarea({ invalid, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime45.jsx)("textarea", { className: cx("sd-textarea", className), "aria-invalid": invalid || void 0, ...rest });
  }
  function AppShell({ sidebar, topBar, testMode, className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime46.jsxs)("div", { className: cx("sd sd-shell", className), ...rest, children: [
      testMode && /* @__PURE__ */ (0, import_jsx_runtime46.jsxs)("div", { className: "sd-testbar", children: [
        /* @__PURE__ */ (0, import_jsx_runtime46.jsx)("span", { className: "sd-testbar__tag", children: "Test mode" }),
        /* @__PURE__ */ (0, import_jsx_runtime46.jsx)("span", { children: "You're using test data. To accept payments, complete your business profile." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime46.jsxs)("div", { className: "sd-shell__body", children: [
        sidebar,
        /* @__PURE__ */ (0, import_jsx_runtime46.jsxs)("div", { className: "sd-shell__main", children: [
          topBar,
          /* @__PURE__ */ (0, import_jsx_runtime46.jsx)("main", { className: "sd-shell__page", children })
        ] })
      ] })
    ] });
  }
  function AuthLayout({ title, wordmark = "stripe", footer, className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime47.jsxs)("div", { className: cx("sd-auth", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime47.jsx)("span", { className: "sd-auth__word", children: wordmark }),
      /* @__PURE__ */ (0, import_jsx_runtime47.jsxs)("div", { className: "sd-auth__card", children: [
        /* @__PURE__ */ (0, import_jsx_runtime47.jsx)("h2", { className: "sd-auth__title", children: title }),
        children,
        footer && /* @__PURE__ */ (0, import_jsx_runtime47.jsx)("div", { className: "sd-auth__foot", children: footer })
      ] })
    ] });
  }
  function Card({ title, info, action, tone = "default", className, children, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime48.jsxs)("div", { className: cx("sd-card", tone !== "default" && `sd-card--${tone}`, className), ...rest, children: [
      (title || action) && /* @__PURE__ */ (0, import_jsx_runtime48.jsxs)("div", { className: "sd-card__head", children: [
        /* @__PURE__ */ (0, import_jsx_runtime48.jsxs)("h3", { className: "sd-card__title", children: [
          title,
          info && /* @__PURE__ */ (0, import_jsx_runtime48.jsx)(Icon, { name: "info" })
        ] }),
        action
      ] }),
      children
    ] });
  }
  function PageHeader({ title, titleSuffix, badge, eyebrow, eyebrowIcon, subtitle, breadcrumb, actions, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime49.jsxs)("div", { className: cx("sd-pagehead", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime49.jsxs)("div", { style: { display: "grid", gap: 4 }, children: [
        breadcrumb,
        eyebrow && /* @__PURE__ */ (0, import_jsx_runtime49.jsxs)("span", { className: "sd-eyebrow", children: [
          eyebrowIcon && /* @__PURE__ */ (0, import_jsx_runtime49.jsx)(Icon, { name: eyebrowIcon }),
          eyebrow
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime49.jsxs)("h1", { className: "sd-pagehead__title", children: [
          title,
          titleSuffix && /* @__PURE__ */ (0, import_jsx_runtime49.jsx)("small", { children: titleSuffix }),
          badge
        ] }),
        subtitle && /* @__PURE__ */ (0, import_jsx_runtime49.jsx)("div", { className: "sd-pagehead__sub", children: subtitle })
      ] }),
      actions && /* @__PURE__ */ (0, import_jsx_runtime49.jsx)("div", { className: "sd-pagehead__actions", children: actions })
    ] });
  }
  function SectionTitle({ children, action, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime50.jsxs)("h2", { className: cx("sd-section-title", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime50.jsx)("span", { children }),
      action
    ] });
  }
  function Breadcrumb({ items, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime51.jsx)("nav", { "aria-label": "Breadcrumb", className: cx("sd-crumbs", className), ...rest, children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime51.jsxs)(React4.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime51.jsx)("a", { href: it.href, children: it.label }),
      /* @__PURE__ */ (0, import_jsx_runtime51.jsx)(Icon, { name: "chev-right" })
    ] }, it.label)) });
  }
  function FocusHeader({ title, status, actions, onClose, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime52.jsxs)("header", { className: cx("sd-focushead", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime52.jsx)("button", { type: "button", className: "sd-close", "aria-label": "Close", onClick: onClose, children: /* @__PURE__ */ (0, import_jsx_runtime52.jsx)(Icon, { name: "x" }) }),
      /* @__PURE__ */ (0, import_jsx_runtime52.jsx)("span", { className: "sd-focushead__sep" }),
      /* @__PURE__ */ (0, import_jsx_runtime52.jsx)("span", { className: "sd-focushead__title", children: title }),
      /* @__PURE__ */ (0, import_jsx_runtime52.jsxs)("div", { className: "sd-focushead__right", children: [
        status && /* @__PURE__ */ (0, import_jsx_runtime52.jsx)("span", { style: { fontSize: 12, color: "var(--text-muted)" }, children: status }),
        actions
      ] })
    ] });
  }
  function Pagination({ summary, hasPrevious, hasNext, onPrevious, onNext, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime53.jsxs)("div", { className: cx("sd-pager", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime53.jsx)("span", { children: summary }),
      /* @__PURE__ */ (0, import_jsx_runtime53.jsxs)("span", { className: "sd-pager__btns", children: [
        /* @__PURE__ */ (0, import_jsx_runtime53.jsx)("button", { type: "button", className: "sd-btn sd-btn--sm", disabled: !hasPrevious, onClick: onPrevious, children: "Previous" }),
        /* @__PURE__ */ (0, import_jsx_runtime53.jsx)("button", { type: "button", className: "sd-btn sd-btn--sm", disabled: !hasNext, onClick: onNext, children: "Next" })
      ] })
    ] });
  }
  function Sidebar({ accountName, accountInitials, sections, footerItem, onNavigate, className, ...rest }) {
    const item = (it) => /* @__PURE__ */ (0, import_jsx_runtime54.jsxs)(React5.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime54.jsxs)("a", { className: "sd-nav__item", href: it.href, "aria-current": it.current ? "page" : void 0, onClick: () => onNavigate?.(it), children: [
        it.icon && /* @__PURE__ */ (0, import_jsx_runtime54.jsx)(Icon, { name: it.icon }),
        it.label,
        (it.expandable || it.children) && /* @__PURE__ */ (0, import_jsx_runtime54.jsx)(Icon, { name: "chev-down", className: "sd-nav__chev" })
      ] }),
      it.children && /* @__PURE__ */ (0, import_jsx_runtime54.jsx)("div", { className: "sd-nav__sub", children: it.children.map(item) })
    ] }, it.label);
    return /* @__PURE__ */ (0, import_jsx_runtime54.jsxs)("nav", { "aria-label": "Main", className: cx("sd-sidebar", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime54.jsxs)("div", { className: "sd-account", children: [
        /* @__PURE__ */ (0, import_jsx_runtime54.jsx)("span", { className: "sd-account__logo", children: accountInitials ?? accountName.slice(0, 2).toUpperCase() }),
        accountName
      ] }),
      sections.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime54.jsxs)("div", { className: "sd-nav", children: [
        s.label && /* @__PURE__ */ (0, import_jsx_runtime54.jsx)("div", { className: "sd-nav__label", children: s.label }),
        s.items.map(item)
      ] }, i)),
      footerItem && /* @__PURE__ */ (0, import_jsx_runtime54.jsx)("div", { className: "sd-nav", style: { marginTop: "auto" }, children: item(footerItem) })
    ] });
  }
  function Stepper({ steps, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime55.jsx)("ol", { className: cx("sd-stepper", className), ...rest, children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime55.jsxs)(React6.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime55.jsxs)("li", { className: cx("sd-step", `sd-step--${s.status}`), "aria-current": s.status === "active" ? "step" : void 0, children: [
        /* @__PURE__ */ (0, import_jsx_runtime55.jsx)("span", { className: "sd-step__node", children: s.status === "done" ? /* @__PURE__ */ (0, import_jsx_runtime55.jsx)(Icon, { name: "check", size: "sm" }) : i + 1 }),
        s.label
      ] }),
      s.substeps?.map((ss) => /* @__PURE__ */ (0, import_jsx_runtime55.jsx)("li", { className: "sd-step sd-step--sub", "aria-current": ss.current ? "step" : void 0, children: ss.label }, ss.label))
    ] }, s.label)) });
  }
  function Tabs({ items, value, onChange, size = "md", className, ...rest }) {
    const norm = items.map((i) => typeof i === "string" ? { label: i, value: i } : i);
    const cur = value ?? norm[0]?.value;
    return /* @__PURE__ */ (0, import_jsx_runtime56.jsx)("div", { role: "tablist", className: cx("sd-tabs", size === "sm" && "sd-tabs--sm", className), ...rest, children: norm.map((t) => /* @__PURE__ */ (0, import_jsx_runtime56.jsx)("button", { type: "button", role: "tab", "aria-selected": t.value === cur, className: "sd-tab", onClick: () => onChange?.(t.value), children: t.label }, t.value)) });
  }
  var ICONS = [["grid", "Apps"], ["help", "Help"], ["bell", "Notifications"], ["gear", "Settings"]];
  function TopBar({ searchPlaceholder, testMode = false, onTestModeChange, unread, onCreate, className, ...rest }) {
    return /* @__PURE__ */ (0, import_jsx_runtime57.jsxs)("header", { className: cx("sd-topbar", className), ...rest, children: [
      /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(SearchInput, { placeholder: searchPlaceholder }),
      /* @__PURE__ */ (0, import_jsx_runtime57.jsxs)("div", { className: "sd-topbar__right", children: [
        /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(Switch, { tone: "testmode", labelPosition: "start", label: "Test mode", checked: testMode, onChange: (e) => onTestModeChange?.(e.target.checked) }),
        ICONS.map(([n, l]) => /* @__PURE__ */ (0, import_jsx_runtime57.jsx)("button", { type: "button", "aria-label": l, className: cx("sd-topbar__icon", n === "bell" && unread && "sd-topbar__dot"), children: /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(Icon, { name: n }) }, n)),
        /* @__PURE__ */ (0, import_jsx_runtime57.jsx)(PlusButton, { onClick: onCreate })
      ] })
    ] });
  }
  return __toCommonJS(index_exports);
})();
window.StripeDashboard=StripeDashboard.__dsMainNs?Object.assign({},StripeDashboard,StripeDashboard.__dsMainNs,{__dsMainNs:undefined}):StripeDashboard;
