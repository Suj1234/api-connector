import * as React from 'react';

/**
 * Banner — from stripe-dashboard-ds@0.1.0.
 */
export interface BannerProps {
  /** neutral = recommendations/tips · critical = blocking account problems · warning = time-sensitive · success = confirmatio */
  tone?: "neutral" | "success" | "warning" | "critical" | "navy";
  /** Leading icon; defaults per tone (bulb, alert, clock, check-circle, transactions). */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Bold first line. */
  title?: React.ReactNode;
  /** Right-side actions: a Link or small Button. */
  actions?: React.ReactNode;
  /** Shows a dismiss x (non-blocking banners only). */
  onDismiss?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Banner: React.ComponentType<BannerProps>;
