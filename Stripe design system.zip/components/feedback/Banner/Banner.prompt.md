Banner from stripe-dashboard-ds. Use via `window.StripeDashboard.Banner` (bundle loaded from the root `_ds_bundle.js`).

An inline page or section message: recommendation, critical account issue, warning, success or navy promo.
@category feedback

## Props

```ts
interface BannerProps {
  /** neutral = recommendations/tips · critical = blocking account problems · warning = time-sensitive · success = confirmatio */
  tone?: "neutral" | "success" | "warning" | "critical" | "navy";
  /** Leading icon; defaults per tone (bulb, alert, clock, check-circle, transactions). */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Bold first line. */
  title?: React.ReactNode;
  /** Right-side actions: a Link or small Button. */
  actions?: React.ReactNode;
  /** Shows a dismiss x (non-blocking banners only). */
  onDismiss?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Recommendation

```jsx
() => (
  <Banner actions={<Link href="#">Install Xero</Link>} onDismiss={() => {}}>
    <b>Recommendation</b>&nbsp; Get quick financial insights based on your latest Stripe data with the Xero app.
  </Banner>
)
```

### Critical

```jsx
() => (
  <Banner tone="critical" title="Payouts paused until requirements are met" actions={<Button size="sm">Add information</Button>}>
    Provide your business representative information to resume payouts. <Link href="#">View details</Link>
  </Banner>
)
```

### Warning

```jsx
() => (
  <Banner tone="warning" actions={<><Link href="#">Learn more</Link><Button size="sm">Advance time</Button></>}>
    The clock time is 10 December 2024 at 10:33 GMT+7
  </Banner>
)
```

### Success

```jsx
() => (
  <Banner tone="success" title="Quote created successfully">
    To send to your customer, <Link href="#">download PDF</Link>.
  </Banner>
)
```

### Promo

```jsx
() => (
  <Banner tone="navy" title="Learn how to set up subscriptions" actions={<Button size="sm" iconEnd="chev-right">Get started</Button>}>
    Use a personalised starter guide based on your pricing model.
  </Banner>
)
```
