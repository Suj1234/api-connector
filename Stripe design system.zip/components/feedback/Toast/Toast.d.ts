import * as React from 'react';

/**
 * Toast — from stripe-dashboard-ds@0.1.0.
 */
export interface ToastProps {
  /** Past-tense confirmation, e.g. "Customer created". */
  children: React.ReactNode;
  /** Optional single action label, e.g. "Undo", "View". */
  actionLabel?: string;
  /** Called when the action is clicked. */
  onAction?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Toast: React.ComponentType<ToastProps>;
