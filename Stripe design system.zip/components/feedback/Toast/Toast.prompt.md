Toast from stripe-dashboard-ds. Use via `window.StripeDashboard.Toast` (bundle loaded from the root `_ds_bundle.js`).

A dark pill confirming a completed action, with an optional Undo or View action.
@category feedback

## Props

```ts
interface ToastProps {
  /** Past-tense confirmation, e.g. "Customer created". */
  children: React.ReactNode;
  /** Optional single action label, e.g. "Undo", "View". */
  actionLabel?: string;
  /** Called when the action is clicked. */
  onAction?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### WithAction

```jsx
() => <Toast actionLabel="View">Customer created</Toast>
```

### Undo

```jsx
() => <Toast actionLabel="Undo">Added to block list</Toast>
```

### Plain

```jsx
() => <Toast>Invoice sent to iamleonardkim@gmail.com</Toast>
```
