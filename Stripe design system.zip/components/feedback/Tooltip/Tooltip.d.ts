import * as React from 'react';

/**
 * Tooltip — from stripe-dashboard-ds@0.1.0.
 */
export interface TooltipProps {
  /** Tooltip text, e.g. "Copy link". */
  children: React.ReactNode;
  /** Shortcut chip, e.g. "⌘ ⌥ L". */
  shortcut?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Tooltip: React.ComponentType<TooltipProps>;
