Tooltip from stripe-dashboard-ds. Use via `window.StripeDashboard.Tooltip` (bundle loaded from the root `_ds_bundle.js`).

The small dark label for icon-only controls, optionally with a shortcut. Position it yourself next to its trigger.
@category feedback

## Props

```ts
interface TooltipProps {
  /** Tooltip text, e.g. "Copy link". */
  children: React.ReactNode;
  /** Shortcut chip, e.g. "⌘ ⌥ L". */
  shortcut?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### WithShortcut

```jsx
() => <Tooltip shortcut="⌘ ⌥ L">Copy link</Tooltip>
```

### OverTrigger

```jsx
() => (
  <div style={{ display: 'grid', justifyItems: 'center', gap: 6, width: 120 }}>
    <Tooltip>Collapse</Tooltip>
    <Button size="sm" icon="chev-left" aria-label="Collapse" />
  </div>
)
```
