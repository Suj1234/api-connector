// Re-export of stripe-dashboard-ds@0.1.0 Tooltip. Implementation is in the root _ds_bundle.js (window.StripeDashboard).
Object.assign(window, { Tooltip: window.StripeDashboard.Tooltip });
