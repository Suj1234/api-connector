Spinner from stripe-dashboard-ds. Use via `window.StripeDashboard.Spinner` (bundle loaded from the root `_ds_bundle.js`).

A blurple loading ring on a pale track.
@category feedback

## Props

```ts
interface SpinnerProps {
  /** sm 16px inline (inside buttons), lg 24px for panel loads. */
  size?: "sm" | "lg";
  /** Accessible label (default "Loading"). */
  label?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Sizes

```jsx
() => (
  <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
    <Spinner />
    <Spinner size="lg" />
  </div>
)
```

### PanelLoad

```jsx
() => (
  <div style={{ display: 'grid', justifyItems: 'center', gap: 8, width: 240, padding: 24, color: 'var(--text-muted)' }}>
    <Spinner size="lg" label="Preparing export" />
    Preparing export…
  </div>
)
```
