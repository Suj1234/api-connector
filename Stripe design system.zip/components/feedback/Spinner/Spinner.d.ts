import * as React from 'react';

/**
 * Spinner — from stripe-dashboard-ds@0.1.0.
 */
export interface SpinnerProps {
  /** sm 16px inline (inside buttons), lg 24px for panel loads. */
  size?: "sm" | "lg";
  /** Accessible label (default "Loading"). */
  label?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Spinner: React.ComponentType<SpinnerProps>;
