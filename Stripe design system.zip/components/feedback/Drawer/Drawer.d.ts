import * as React from 'react';

/**
 * Drawer — from stripe-dashboard-ds@0.1.0.
 */
export interface DrawerProps {
  /** Render nothing when false. */
  open?: boolean;
  /** Sheet title. */
  title: React.ReactNode;
  /** Blurple line above the title for multi-step flows, e.g. "AUTOMATION · Step 1 of 2". */
  eyebrow?: React.ReactNode;
  /** Close handler for the x and the scrim. */
  onClose?: () => void;
  /** Left side of the footer, usually a help Link. */
  footerStart?: React.ReactNode;
  /** Right side of the footer: Cancel and the primary. */
  footer?: React.ReactNode;
  /** Sheet width in px (default 440). */
  width?: number;
  /** Render in place instead of fixed to the right edge. */
  inline?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Drawer: React.ComponentType<DrawerProps>;
