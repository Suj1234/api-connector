Drawer from stripe-dashboard-ds. Use via `window.StripeDashboard.Drawer` (bundle loaded from the root `_ds_bundle.js`).

A right-side sheet for creating one object without leaving the list, with a sticky footer.
@category feedback

## Props

```ts
interface DrawerProps {
  /** Render nothing when false. */
  open?: boolean;
  /** Sheet title. */
  title: React.ReactNode;
  /** Blurple line above the title for multi-step flows, e.g. "AUTOMATION · Step 1 of 2". */
  eyebrow?: React.ReactNode;
  /** Close handler for the x and the scrim. */
  onClose?: () => void;
  /** Left side of the footer, usually a help Link. */
  footerStart?: React.ReactNode;
  /** Right side of the footer: Cancel and the primary. */
  footer?: React.ReactNode;
  /** Sheet width in px (default 440). */
  width?: number;
  /** Render in place instead of fixed to the right edge. */
  inline?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### CreateFeature

```jsx
() => (
  <div style={{ width: 620, height: 520 }}>
    <Drawer inline width={480} title="Create feature" onClose={() => {}}
      footerStart={<Link href="#" external>Learn more about features</Link>}
      footer={<><Button>Cancel</Button><Button variant="primary">Create feature</Button></>}>
      <Field label="Feature name" htmlFor="fn" help="This won't be shown to customers."><TextInput id="fn" defaultValue="Personal CS" /></Field>
      <Field label="Lookup key" htmlFor="lk" help="A unique key you provide as your own identifier."><TextInput id="lk" defaultValue="cs-001" /></Field>
      <Link href="#">+ Add metadata</Link>
    </Drawer>
  </div>
)
```

### MultiStep

```jsx
() => (
  <div style={{ width: 620, height: 420 }}>
    <Drawer inline eyebrow="AUTOMATION · Step 1 of 2" title="Overdue invoice" onClose={() => {}}
      footerStart={<Link href="#" external>View the step-by-step guide</Link>}
      footer={<Button variant="primary">Continue</Button>}>
      <Field label="Name" htmlFor="an" help="Add a name to the automation."><TextInput id="an" defaultValue="Overdue invoice" /></Field>
    </Drawer>
  </div>
)
```
