// Re-export of stripe-dashboard-ds@0.1.0 TourPopover. Implementation is in the root _ds_bundle.js (window.StripeDashboard).
Object.assign(window, { TourPopover: window.StripeDashboard.TourPopover });
