TourPopover from stripe-dashboard-ds. Use via `window.StripeDashboard.TourPopover` (bundle loaded from the root `_ds_bundle.js`).

A navy 240px popover for one step of an in-product tour, with "Skip tour" and "Next".
@category feedback

## Props

```ts
interface TourPopoverProps {
  /** Step text. */
  children: React.ReactNode;
  /** Label of the advance button (default "Next"; "Done" on the last step). */
  nextLabel?: string;
  /** Called on the advance button. */
  onNext?: () => void;
  /** Called on "Skip tour". */
  onSkip?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### Step

```jsx
() => (
  <TourPopover>Enter a name or email address to get started. Adding a customer allows you to save payment methods and track multiple charges.</TourPopover>
)
```

### LastStep

```jsx
() => (
  <TourPopover nextLabel="Done">Add a one-off item to your invoice or save a product for future use. You also have the option to add a tax rate, coupon, or supply date.</TourPopover>
)
```
