import * as React from 'react';

/**
 * TourPopover — from stripe-dashboard-ds@0.1.0.
 */
export interface TourPopoverProps {
  /** Step text. */
  children: React.ReactNode;
  /** Label of the advance button (default "Next"; "Done" on the last step). */
  nextLabel?: string;
  /** Called on the advance button. */
  onNext?: () => void;
  /** Called on "Skip tour". */
  onSkip?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const TourPopover: React.ComponentType<TourPopoverProps>;
