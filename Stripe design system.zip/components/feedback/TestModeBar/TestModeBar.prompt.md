TestModeBar from stripe-dashboard-ds. Use via `window.StripeDashboard.TestModeBar` (bundle loaded from the root `_ds_bundle.js`).

The 28px orange bar pinned above the whole dashboard while Test mode is on.
@category feedback

## Props

```ts
interface TestModeBarProps {
  /** Centred message; defaults to the standard test-data notice. */
  children?: React.ReactNode;
  /** Optional right-hand link, e.g. <a href="…">Complete profile</a>. */
  action?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### Default

```jsx
() => <div style={{ width: 900 }}><TestModeBar /></div>
```

### WithLink

```jsx
() => (
  <div style={{ width: 900 }}>
    <TestModeBar action={<a href="#">Learn more about test mode</a>}>You're using test data. No real transactions will be processed.</TestModeBar>
  </div>
)
```
