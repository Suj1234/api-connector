import * as React from 'react';

/**
 * TestModeBar — from stripe-dashboard-ds@0.1.0.
 */
export interface TestModeBarProps {
  /** Centred message; defaults to the standard test-data notice. */
  children?: React.ReactNode;
  /** Optional right-hand link, e.g. <a href="…">Complete profile</a>. */
  action?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const TestModeBar: React.ComponentType<TestModeBarProps>;
