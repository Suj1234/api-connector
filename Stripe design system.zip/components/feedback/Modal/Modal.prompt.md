Modal from stripe-dashboard-ds. Use via `window.StripeDashboard.Modal` (bundle loaded from the root `_ds_bundle.js`).

A centred dialog over a grey-blue scrim with a title, a close x, a body and a right-aligned footer.
@category feedback

## Props

```ts
interface ModalProps {
  /** Render nothing when false. */
  open?: boolean;
  /** Dialog title (16px bold). */
  title: React.ReactNode;
  /** Close handler for the x button, the scrim and Escape. */
  onClose?: () => void;
  /** Footer buttons, right-aligned: secondary Cancel, then the primary naming the action. */
  footer?: React.ReactNode;
  /** Dialog width in px (default 480). */
  width?: number;
  /** Render in place instead of fixed over the page (for embedding in docs). */
  inline?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### RefundPayment

```jsx
() => (
  <Modal inline title="Refund payment" onClose={() => {}} footer={<><Button shortcut="esc">Cancel</Button><Button variant="primary" shortcut="⌘ ↵">Refund MYR 0.50</Button></>}>
    <Banner icon="info">Refunds take 5–10 days to appear on a customer's statement. <Link href="#">Learn more</Link></Banner>
    <Field label="Refund" htmlFor="refund-amt"><TextInput id="refund-amt" defaultValue="0.50" suffix="MYR" /></Field>
    <Field label="Reason" htmlFor="refund-reason"><Select id="refund-reason" defaultValue="Requested by customer" options={['Requested by customer', 'Duplicate', 'Fraudulent']} /></Field>
  </Modal>
)
```

### DeleteConfirm

```jsx
() => (
  <Modal inline width={420} title="Delete 1 customer?" onClose={() => {}} footer={<><Button>Cancel</Button><Button variant="danger">Delete</Button></>}>
    <p style={{ margin: 0, color: 'var(--text-subdued)' }}>This will permanently remove the customer's billing information and immediately cancel any current subscriptions. This action cannot be undone.</p>
  </Modal>
)
```
