import * as React from 'react';

/**
 * Modal — from stripe-dashboard-ds@0.1.0.
 * @replaces dialog
 */
export interface ModalProps {
  /** Render nothing when false. */
  open?: boolean;
  /** Dialog title (16px bold). */
  title: React.ReactNode;
  /** Close handler for the x button, the scrim and Escape. */
  onClose?: () => void;
  /** Footer buttons, right-aligned: secondary Cancel, then the primary naming the action. */
  footer?: React.ReactNode;
  /** Dialog width in px (default 480). */
  width?: number;
  /** Render in place instead of fixed over the page (for embedding in docs). */
  inline?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Modal: React.ComponentType<ModalProps>;
