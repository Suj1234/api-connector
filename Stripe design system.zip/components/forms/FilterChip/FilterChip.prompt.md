FilterChip from stripe-dashboard-ds. Use via `window.StripeDashboard.FilterChip` (bundle loaded from the root `_ds_bundle.js`).

The dashed "+ Filter" pill above lists; turns solid and shows its value once applied.
@category forms

## Props

```ts
interface FilterChipProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name (required for icon-only controls). */
  "aria-label"?: string;
  /** Filter name, e.g. "Date and time", "Status". */
  label: string;
  /** Applied value, e.g. "Succeeded". When set, the chip turns solid and shows an x-circle. */
  value?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### FilterRow

```jsx
() => (
  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
    <FilterChip label="Date and time" />
    <FilterChip label="Amount" />
    <FilterChip label="Currency" />
    <FilterChip label="Status" />
    <FilterChip label="Payment method" />
    <FilterChip label="More filters" />
  </div>
)
```

### Applied

```jsx
() => (
  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
    <FilterChip label="Date and time" value="Last 3 days" />
    <FilterChip label="Status" value="Cancelled, Blocked" />
    <FilterChip label="Amount" />
    <Link href="#" style={{ fontSize: 12 }}>Clear filters</Link>
  </div>
)
```
