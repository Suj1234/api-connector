import * as React from 'react';

/**
 * FilterChip — from stripe-dashboard-ds@0.1.0.
 */
export interface FilterChipProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name (required for icon-only controls). */
  "aria-label"?: string;
  /** Filter name, e.g. "Date and time", "Status". */
  label: string;
  /** Applied value, e.g. "Succeeded". When set, the chip turns solid and shows an x-circle. */
  value?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const FilterChip: React.ComponentType<FilterChipProps>;
