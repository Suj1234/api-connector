import * as React from 'react';

/**
 * ChoiceCardGroup — from stripe-dashboard-ds@0.1.0.
 */
export interface ChoiceCardGroupProps {
  /** ChoiceCard elements (2-4). */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const ChoiceCardGroup: React.ComponentType<ChoiceCardGroupProps>;
