ChoiceCardGroup from stripe-dashboard-ds. Use via `window.StripeDashboard.ChoiceCardGroup` (bundle loaded from the root `_ds_bundle.js`).

Lays ChoiceCards out in equal columns that wrap on narrow screens.
@category forms

## Props

```ts
interface ChoiceCardGroupProps {
  /** ChoiceCard elements (2-4). */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### PaymentType

```jsx
() => (
  <ChoiceCardGroup style={{ width: 440 }}>
    <ChoiceCard selected align="center" title="One-time" />
    <ChoiceCard align="center" title="Recurring" />
  </ChoiceCardGroup>
)
```

### AccountCreation

```jsx
() => (
  <ChoiceCardGroup style={{ width: 440, gridTemplateColumns: '1fr' }}>
    <ChoiceCard selected title="Onboarding hosted by Stripe" description="Redirect sellers to an onboarding experience built and hosted by Stripe." />
    <ChoiceCard title="Embedded onboarding components" description="Embed Stripe onboarding components on your platform." />
  </ChoiceCardGroup>
)
```
