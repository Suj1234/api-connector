Checkbox from stripe-dashboard-ds. Use via `window.StripeDashboard.Checkbox` (bundle loaded from the root `_ds_bundle.js`).

A 16px checkbox that fills blurple when checked, with optional label and description.
@category forms

## Props

```ts
interface CheckboxProps {
  /** Element id. */
  id?: string;
  /** Group name (radios with the same name form one group). */
  name?: string;
  /** Value submitted when checked. */
  value?: string;
  /** Controlled checked state. */
  checked?: boolean;
  /** Uncontrolled initial state. */
  defaultChecked?: boolean;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Label next to the control (bold when a description is given). */
  label?: React.ReactNode;
  /** Muted explanation under the label, e.g. the consequence of the choice. */
  description?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### WithDescription

```jsx
() => (
  <div style={{ width: 420 }}>
    <Checkbox defaultChecked label="Add item to product catalogue" description="Adding this item to your product catalogue will allow you to easily re-use it in future invoices." />
  </div>
)
```

### Options

```jsx
() => (
  <div style={{ display: 'grid', gap: 10 }}>
    <Checkbox label="Collect customers' addresses" />
    <Checkbox defaultChecked label="Require customers to provide a phone number" />
    <Checkbox defaultChecked label="Include a free trial" />
    <Checkbox disabled label="Limit the number of payments" />
  </div>
)
```
