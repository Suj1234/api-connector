SearchInput from stripe-dashboard-ds. Use via `window.StripeDashboard.SearchInput` (bundle loaded from the root `_ds_bundle.js`).

The borderless grey search field used in the top bar and list pages.
@category forms

## Props

```ts
interface SearchInputProps {
  /** Element id (link a Field's htmlFor to it). */
  id?: string;
  /** Form field name. */
  name?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Placeholder example text. */
  placeholder?: string;
  /** Disables the control. */
  disabled?: boolean;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### TopBarSearch

```jsx
() => (
  <div style={{ width: 480 }}><SearchInput /></div>
)
```

### FilterByEvent

```jsx
() => (
  <div style={{ width: 280 }}><SearchInput placeholder="Find event by ID…" /></div>
)
```
