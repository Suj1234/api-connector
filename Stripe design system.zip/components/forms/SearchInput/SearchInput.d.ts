import * as React from 'react';

/**
 * SearchInput — from stripe-dashboard-ds@0.1.0.
 */
export interface SearchInputProps {
  /** Element id (link a Field's htmlFor to it). */
  id?: string;
  /** Form field name. */
  name?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Placeholder example text. */
  placeholder?: string;
  /** Disables the control. */
  disabled?: boolean;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const SearchInput: React.ComponentType<SearchInputProps>;
