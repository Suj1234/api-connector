import * as React from 'react';

/**
 * Switch — from stripe-dashboard-ds@0.1.0.
 */
export interface SwitchProps {
  /** Element id. */
  id?: string;
  /** Group name (radios with the same name form one group). */
  name?: string;
  /** Value submitted when checked. */
  value?: string;
  /** Controlled checked state. */
  checked?: boolean;
  /** Uncontrolled initial state. */
  defaultChecked?: boolean;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Label text. */
  label?: React.ReactNode;
  /** Put the label before the switch (top bar) or after it (forms, default). */
  labelPosition?: "start" | "end";
  /** brand (blurple when on) or testmode (orange when on, for the Test mode toggle only). */
  tone?: "brand" | "testmode";
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Switch: React.ComponentType<SwitchProps>;
