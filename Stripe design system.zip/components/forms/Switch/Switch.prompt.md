Switch from stripe-dashboard-ds. Use via `window.StripeDashboard.Switch` (bundle loaded from the root `_ds_bundle.js`).

A 28x16 toggle for settings that apply immediately; the Test mode switch turns orange.
@category forms

## Props

```ts
interface SwitchProps {
  /** Element id. */
  id?: string;
  /** Group name (radios with the same name form one group). */
  name?: string;
  /** Value submitted when checked. */
  value?: string;
  /** Controlled checked state. */
  checked?: boolean;
  /** Uncontrolled initial state. */
  defaultChecked?: boolean;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Label text. */
  label?: React.ReactNode;
  /** Put the label before the switch (top bar) or after it (forms, default). */
  labelPosition?: "start" | "end";
  /** brand (blurple when on) or testmode (orange when on, for the Test mode toggle only). */
  tone?: "brand" | "testmode";
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Setting

```jsx
() => (
  <div style={{ display: 'grid', gap: 12 }}>
    <Switch defaultChecked label="Show phone number on receipts and invoices" />
    <Switch label="Enable address autocomplete" />
  </div>
)
```

### TestMode

```jsx
() => (
  <div style={{ display: 'flex', gap: 32 }}>
    <Switch tone="testmode" labelPosition="start" label="Test mode" />
    <Switch tone="testmode" labelPosition="start" label="Test mode" defaultChecked />
  </div>
)
```
