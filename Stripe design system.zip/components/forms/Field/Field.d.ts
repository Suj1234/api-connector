import * as React from 'react';

/**
 * Field — from stripe-dashboard-ds@0.1.0.
 */
export interface FieldProps {
  /** Label text above the control (sentence case). */
  label?: React.ReactNode;
  /** id of the control, links the label to it. */
  htmlFor?: string;
  /** Shows an "Optional" tag after the label. */
  optional?: boolean;
  /** Help text under the control (muted, 12px). Hidden while an error shows. */
  help?: React.ReactNode;
  /** Error message; replaces help text in red with an alert icon. Also set aria-invalid on the control. */
  error?: React.ReactNode;
  /** The control: TextInput, Select, Textarea, a ChoiceCardGroup... */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Field: React.ComponentType<FieldProps>;
