Field from stripe-dashboard-ds. Use via `window.StripeDashboard.Field` (bundle loaded from the root `_ds_bundle.js`).

Stacks a label, a form control, help text and an error message.
@category forms

## Props

```ts
interface FieldProps {
  /** Label text above the control (sentence case). */
  label?: React.ReactNode;
  /** id of the control, links the label to it. */
  htmlFor?: string;
  /** Shows an "Optional" tag after the label. */
  optional?: boolean;
  /** Help text under the control (muted, 12px). Hidden while an error shows. */
  help?: React.ReactNode;
  /** Error message; replaces help text in red with an alert icon. Also set aria-invalid on the control. */
  error?: React.ReactNode;
  /** The control: TextInput, Select, Textarea, a ChoiceCardGroup... */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### WithHelp

```jsx
() => (
  <div style={{ width: 400 }}>
    <Field label="Name" htmlFor="coupon-name" help="This will appear on customers' receipts and invoices.">
      <TextInput id="coupon-name" defaultValue="First purchase" />
    </Field>
  </div>
)
```

### Optional

```jsx
() => (
  <div style={{ width: 400 }}>
    <Field label="Shortened descriptor" htmlFor="desc" optional help="A short label added to the full statement descriptor.">
      <TextInput id="desc" placeholder="CONTENT-MO" />
    </Field>
  </div>
)
```

### Error

```jsx
() => (
  <div style={{ width: 400 }}>
    <Field label="Amount" htmlFor="amt" error="Amount must be at least MYR 2.00.">
      <TextInput id="amt" prefix="MYR" defaultValue="1.00" invalid />
    </Field>
  </div>
)
```

### WithSelect

```jsx
() => (
  <div style={{ width: 400 }}>
    <Field label="Industry" htmlFor="ind" help="Selecting your industry helps satisfy risk and compliance obligations.">
      <Select id="ind" defaultValue="Software" options={['Software', 'Clothing and accessories', 'Consulting services']} />
    </Field>
  </div>
)
```
