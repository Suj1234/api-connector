ColorInput from stripe-dashboard-ds. Use via `window.StripeDashboard.ColorInput` (bundle loaded from the root `_ds_bundle.js`).

A colour swatch plus a monospace hex field, used in branding settings.
@category forms

## Props

```ts
interface ColorInputProps {
  /** Row label, e.g. "Brand colour". */
  label?: React.ReactNode;
  /** Hex value, e.g. "#294eae". */
  value: string;
  /** Called with the typed hex string. */
  onChange?: (value: string) => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Branding

```jsx
() => (
  <div style={{ width: 320, display: 'grid', gap: 10 }}>
    <ColorInput label="Brand colour" value="#294eae" />
    <ColorInput label="Accent colour" value="#fe63ff" />
  </div>
)
```
