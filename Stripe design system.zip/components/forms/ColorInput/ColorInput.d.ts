import * as React from 'react';

/**
 * ColorInput — from stripe-dashboard-ds@0.1.0.
 */
export interface ColorInputProps {
  /** Row label, e.g. "Brand colour". */
  label?: React.ReactNode;
  /** Hex value, e.g. "#294eae". */
  value: string;
  /** Called with the typed hex string. */
  onChange?: (value: string) => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const ColorInput: React.ComponentType<ColorInputProps>;
