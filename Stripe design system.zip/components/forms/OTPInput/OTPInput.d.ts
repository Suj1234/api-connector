import * as React from 'react';

/**
 * OTPInput — from stripe-dashboard-ds@0.1.0.
 */
export interface OTPInputProps {
  /** Current code (digits only, up to 6). */
  value?: string;
  /** Called with the new code as the user types. */
  onChange?: (value: string) => void;
  /** Disable every box. */
  disabled?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const OTPInput: React.ComponentType<OTPInputProps>;
