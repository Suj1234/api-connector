OTPInput from stripe-dashboard-ds. Use via `window.StripeDashboard.OTPInput` (bundle loaded from the root `_ds_bundle.js`).

Six one-digit boxes in two groups of three for SMS and authenticator codes.
@category forms

## Props

```ts
interface OTPInputProps {
  /** Current code (digits only, up to 6). */
  value?: string;
  /** Called with the new code as the user types. */
  onChange?: (value: string) => void;
  /** Disable every box. */
  disabled?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Empty

```jsx
() => <OTPInput value="" />
```

### PartlyFilled

```jsx
() => <OTPInput value="95608" />
```

### Complete

```jsx
() => <OTPInput value="956080" disabled />
```
