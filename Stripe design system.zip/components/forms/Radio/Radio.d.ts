import * as React from 'react';

/**
 * Radio — from stripe-dashboard-ds@0.1.0.
 * @replaces input[type=radio]
 */
export interface RadioProps {
  /** Element id. */
  id?: string;
  /** Group name (radios with the same name form one group). */
  name?: string;
  /** Value submitted when checked. */
  value?: string;
  /** Controlled checked state. */
  checked?: boolean;
  /** Uncontrolled initial state. */
  defaultChecked?: boolean;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Label next to the control (bold when a description is given). */
  label?: React.ReactNode;
  /** Muted explanation under the label, e.g. the consequence of the choice. */
  description?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Radio: React.ComponentType<RadioProps>;
