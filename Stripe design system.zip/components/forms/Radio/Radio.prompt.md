Radio from stripe-dashboard-ds. Use via `window.StripeDashboard.Radio` (bundle loaded from the root `_ds_bundle.js`).

A radio option with a bold title and a muted description; group options by giving them the same name.
@category forms

## Props

```ts
interface RadioProps {
  /** Element id. */
  id?: string;
  /** Group name (radios with the same name form one group). */
  name?: string;
  /** Value submitted when checked. */
  value?: string;
  /** Controlled checked state. */
  checked?: boolean;
  /** Uncontrolled initial state. */
  defaultChecked?: boolean;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Label next to the control (bold when a description is given). */
  label?: React.ReactNode;
  /** Muted explanation under the label, e.g. the consequence of the choice. */
  description?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### PaymentCollection

```jsx
() => (
  <div style={{ display: 'grid', gap: 12, width: 420 }}>
    <Radio name="collect" defaultChecked label="Request payment" description="Create an invoice requesting payment on a specific date." />
    <Radio name="collect" label="Autocharge customer" description="Automatically charge a payment method on file." />
  </div>
)
```

### PayoutSchedule

```jsx
() => (
  <div style={{ display: 'grid', gap: 12, width: 420 }}>
    <Radio name="sched" label="Automatic every day" description="When choosing a weekly or monthly schedule, you can specify your preferred payout day." />
    <Radio name="sched" defaultChecked label="Manual" description="You can manually initiate a payout from Stripe whenever your funds are available." />
  </div>
)
```
