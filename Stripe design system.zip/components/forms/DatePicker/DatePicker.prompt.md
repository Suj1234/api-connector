DatePicker from stripe-dashboard-ds. Use via `window.StripeDashboard.DatePicker` (bundle loaded from the root `_ds_bundle.js`).

A popover calendar (Monday-first) with an optional shortcuts column.
@category forms

## Props

```ts
interface DatePickerProps {
  /** Month shown, as "YYYY-MM". Defaults to the selected date's month. */
  month?: string;
  /** Selected day, "YYYY-MM-DD". */
  value?: string;
  /** Earliest selectable day, "YYYY-MM-DD"; earlier days are greyed. */
  min?: string;
  /** Called with "YYYY-MM-DD" when a day is clicked. */
  onSelect?: (value: string) => void;
  /** Called with the new "YYYY-MM" from the arrows. */
  onMonthChange?: (month: string) => void;
  /** Optional shortcut links shown in a right column, e.g. ["+1 hour", "+1 day"]. */
  shortcuts?: string[];
  /** Called with the shortcut label. */
  onShortcut?: (label: string) => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### ScheduleDate

```jsx
() => <DatePicker value="2024-12-06" min="2024-12-06" />
```

### TestClock

```jsx
() => (
  <DatePicker month="2025-01" value="2025-01-10" min="2024-12-10" shortcuts={['+1 hour', '+1 day', '+1 week', '+1 month', '+1 year']} />
)
```
