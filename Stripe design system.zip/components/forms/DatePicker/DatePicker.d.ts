import * as React from 'react';

/**
 * DatePicker — from stripe-dashboard-ds@0.1.0.
 */
export interface DatePickerProps {
  /** Month shown, as "YYYY-MM". Defaults to the selected date's month. */
  month?: string;
  /** Selected day, "YYYY-MM-DD". */
  value?: string;
  /** Earliest selectable day, "YYYY-MM-DD"; earlier days are greyed. */
  min?: string;
  /** Called with "YYYY-MM-DD" when a day is clicked. */
  onSelect?: (value: string) => void;
  /** Called with the new "YYYY-MM" from the arrows. */
  onMonthChange?: (month: string) => void;
  /** Optional shortcut links shown in a right column, e.g. ["+1 hour", "+1 day"]. */
  shortcuts?: string[];
  /** Called with the shortcut label. */
  onShortcut?: (label: string) => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const DatePicker: React.ComponentType<DatePickerProps>;
