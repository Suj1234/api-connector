import * as React from 'react';

/**
 * ChoiceCard — from stripe-dashboard-ds@0.1.0.
 */
export interface ChoiceCardProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name (required for icon-only controls). */
  "aria-label"?: string;
  /** Main line, e.g. "Recurring" or "1%". */
  title: React.ReactNode;
  /** Muted second line, e.g. "Charge an ongoing fee". */
  description?: React.ReactNode;
  /** Small muted line above the title, e.g. "MOST POPULAR". */
  eyebrow?: React.ReactNode;
  /** Selected state: blurple border and ring, blurple title. */
  selected?: boolean;
  /** start (default) or center-aligned content. */
  align?: "start" | "center";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const ChoiceCard: React.ComponentType<ChoiceCardProps>;
