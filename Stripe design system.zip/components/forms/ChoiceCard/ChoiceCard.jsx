// Re-export of stripe-dashboard-ds@0.1.0 ChoiceCard. Implementation is in the root _ds_bundle.js (window.StripeDashboard).
Object.assign(window, { ChoiceCard: window.StripeDashboard.ChoiceCard });
