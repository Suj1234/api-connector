ChoiceCard from stripe-dashboard-ds. Use via `window.StripeDashboard.ChoiceCard` (bundle loaded from the root `_ds_bundle.js`).

A bordered option button used as one choice of a radio group (pricing type, payment type, percentages).
@category forms

## Props

```ts
interface ChoiceCardProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name (required for icon-only controls). */
  "aria-label"?: string;
  /** Main line, e.g. "Recurring" or "1%". */
  title: React.ReactNode;
  /** Muted second line, e.g. "Charge an ongoing fee". */
  description?: React.ReactNode;
  /** Small muted line above the title, e.g. "MOST POPULAR". */
  eyebrow?: React.ReactNode;
  /** Selected state: blurple border and ring, blurple title. */
  selected?: boolean;
  /** start (default) or center-aligned content. */
  align?: "start" | "center";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### PricingType

```jsx
() => (
  <ChoiceCardGroup style={{ width: 440 }}>
    <ChoiceCard selected title="Recurring" description="Charge an ongoing fee" />
    <ChoiceCard title="One-off" description="Charge a one-off fee" />
  </ChoiceCardGroup>
)
```

### Percentages

```jsx
() => (
  <ChoiceCardGroup style={{ width: 440 }}>
    <ChoiceCard align="center" title="0.5%" />
    <ChoiceCard align="center" selected eyebrow="MOST POPULAR" title="1%" description="of revenue" />
    <ChoiceCard align="center" title="1.5%" />
  </ChoiceCardGroup>
)
```

## Related

`ChoiceCardGroup`
