TextInput from stripe-dashboard-ds. Use via `window.StripeDashboard.TextInput` (bundle loaded from the root `_ds_bundle.js`).

Single-line text input with optional currency prefix and trailing select.
@category forms

## Props

```ts
interface TextInputProps {
  /** Element id (link a Field's htmlFor to it). */
  id?: string;
  /** Form field name. */
  name?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Placeholder example text. */
  placeholder?: string;
  /** Disables the control. */
  disabled?: boolean;
  /** Input type, e.g. 'email', 'password'. */
  type?: string;
  /** md 32px (default) or lg 40px (auth and onboarding). */
  size?: "md" | "lg";
  /** Leading text inside the box, e.g. a currency code "MYR". */
  prefix?: React.ReactNode;
  /** Trailing element inside the box, e.g. a currency Select or a unit "%". */
  suffix?: React.ReactNode;
  /** Red border for validation errors (pair with Field error). */
  invalid?: boolean;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Default

```jsx
() => (
  <div style={{ width: 360, display: 'grid', gap: 12 }}>
    <TextInput placeholder="Find or add a customer…" />
    <TextInput defaultValue="samlee@content-mobbin.com" type="email" />
  </div>
)
```

### Amount

```jsx
() => (
  <div style={{ width: 360 }}>
    <TextInput prefix="MYR" defaultValue="2.00" aria-label="Amount" suffix={<Select aria-label="Currency" defaultValue="MYR" options={['MYR', 'USD', 'SGD']} />} />
  </div>
)
```

### Percentage

```jsx
() => (
  <div style={{ width: 200 }}>
    <TextInput defaultValue="10" suffix="%" aria-label="Percentage off" />
  </div>
)
```

### States

```jsx
() => (
  <div style={{ width: 360, display: 'grid', gap: 12 }}>
    <TextInput defaultValue="acct_1QRP3eP1CRBSqB" disabled />
    <TextInput defaultValue="1.00" invalid />
  </div>
)
```

### Large

```jsx
() => (
  <div style={{ width: 360 }}>
    <TextInput size="lg" placeholder="Email" type="email" />
  </div>
)
```
