import * as React from 'react';

/**
 * TextInput — from stripe-dashboard-ds@0.1.0.
 * @replaces input
 */
export interface TextInputProps {
  /** Element id (link a Field's htmlFor to it). */
  id?: string;
  /** Form field name. */
  name?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Placeholder example text. */
  placeholder?: string;
  /** Disables the control. */
  disabled?: boolean;
  /** Input type, e.g. 'email', 'password'. */
  type?: string;
  /** md 32px (default) or lg 40px (auth and onboarding). */
  size?: "md" | "lg";
  /** Leading text inside the box, e.g. a currency code "MYR". */
  prefix?: React.ReactNode;
  /** Trailing element inside the box, e.g. a currency Select or a unit "%". */
  suffix?: React.ReactNode;
  /** Red border for validation errors (pair with Field error). */
  invalid?: boolean;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const TextInput: React.ComponentType<TextInputProps>;
