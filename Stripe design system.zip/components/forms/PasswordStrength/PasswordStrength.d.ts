import * as React from 'react';

/**
 * PasswordStrength — from stripe-dashboard-ds@0.1.0.
 */
export interface PasswordStrengthProps {
  /** 0-4 filled segments; 3+ reads as strong. */
  level: 0 | 1 | 2 | 3 | 4;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const PasswordStrength: React.ComponentType<PasswordStrengthProps>;
