PasswordStrength from stripe-dashboard-ds. Use via `window.StripeDashboard.PasswordStrength` (bundle loaded from the root `_ds_bundle.js`).

A four-segment green strength meter under new-password fields.
@category forms

## Props

```ts
interface PasswordStrengthProps {
  /** 0-4 filled segments; 3+ reads as strong. */
  level: 0 | 1 | 2 | 3 | 4;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Strong

```jsx
() => (
  <div style={{ width: 360 }}>
    <Field label="Password" htmlFor="pw">
      <TextInput id="pw" type="password" defaultValue="correct-horse-battery" />
      <PasswordStrength level={4} />
    </Field>
  </div>
)
```

### Weak

```jsx
() => (
  <div style={{ width: 360 }}>
    <Field label="New password" htmlFor="pw2" help="Your password works, but could be stronger. Try making it longer.">
      <TextInput id="pw2" type="password" defaultValue="stripe12" />
      <PasswordStrength level={2} />
    </Field>
  </div>
)
```
