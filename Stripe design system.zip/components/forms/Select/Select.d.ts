import * as React from 'react';

/**
 * Select — from stripe-dashboard-ds@0.1.0.
 * @replaces select
 */
export interface SelectProps {
  /** Element id (link a Field's htmlFor to it). */
  id?: string;
  /** Form field name. */
  name?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLSelectElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Options; strings use the same text for value and label. */
  options?: SelectOption[];
  /** Adds a disabled first option like "Choose a currency…". */
  placeholder?: string;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Select: React.ComponentType<SelectProps>;
