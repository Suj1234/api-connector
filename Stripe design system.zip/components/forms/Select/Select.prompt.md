Select from stripe-dashboard-ds. Use via `window.StripeDashboard.Select` (bundle loaded from the root `_ds_bundle.js`).

Native select with Stripe's stacked up/down chevron; same box as TextInput.
@category forms

## Props

```ts
interface SelectProps {
  /** Element id (link a Field's htmlFor to it). */
  id?: string;
  /** Form field name. */
  name?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLSelectElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Options; strings use the same text for value and label. */
  options?: SelectOption[];
  /** Adds a disabled first option like "Choose a currency…". */
  placeholder?: string;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### BillingPeriod

```jsx
() => (
  <div style={{ width: 320 }}>
    <Field label="Billing period" htmlFor="bp">
      <Select id="bp" defaultValue="Monthly" options={['Daily', 'Weekly', 'Monthly', 'Every 3 months', 'Every 6 months', 'Yearly']} />
    </Field>
  </div>
)
```

### Placeholder

```jsx
() => (
  <div style={{ width: 320 }}>
    <Field label="Currency" htmlFor="cur" help="Selecting a new currency will clear all items from the invoice.">
      <Select id="cur" placeholder="Choose a currency…" options={[{ value: 'USD', label: 'USD - US Dollar' }, { value: 'MYR', label: 'MYR - Malaysian Ringgit' }]} />
    </Field>
  </div>
)
```
