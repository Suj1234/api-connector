Textarea from stripe-dashboard-ds. Use via `window.StripeDashboard.Textarea` (bundle loaded from the root `_ds_bundle.js`).

Multi-line text input for descriptions, memos, footers and internal notes.
@category forms

## Props

```ts
interface TextareaProps {
  /** Element id (link a Field's htmlFor to it). */
  id?: string;
  /** Form field name. */
  name?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLTextAreaElement>;
  /** Placeholder example text. */
  placeholder?: string;
  /** Disables the control. */
  disabled?: boolean;
  /** Visible rows. */
  rows?: number;
  /** Red border for validation errors. */
  invalid?: boolean;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### ProductDescription

```jsx
() => (
  <div style={{ width: 420 }}>
    <Field label="Product description" htmlFor="pd" help="Provide a 1–2 sentence description. Make sure to note when you typically charge your customers.">
      <Textarea id="pd" defaultValue="It's a go-to resource for designers and developers to explore and analyse well-crafted designs for inspiration and best practices." />
    </Field>
  </div>
)
```

### Memo

```jsx
() => (
  <div style={{ width: 420 }}>
    <Field label="Memo" htmlFor="memo" optional>
      <Textarea id="memo" placeholder="Thanks for your business!" />
    </Field>
  </div>
)
```
