import * as React from 'react';

/**
 * Textarea — from stripe-dashboard-ds@0.1.0.
 * @replaces textarea
 */
export interface TextareaProps {
  /** Element id (link a Field's htmlFor to it). */
  id?: string;
  /** Form field name. */
  name?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Change handler. */
  onChange?: React.ChangeEventHandler<HTMLTextAreaElement>;
  /** Placeholder example text. */
  placeholder?: string;
  /** Disables the control. */
  disabled?: boolean;
  /** Visible rows. */
  rows?: number;
  /** Red border for validation errors. */
  invalid?: boolean;
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Textarea: React.ComponentType<TextareaProps>;
