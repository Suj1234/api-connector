import * as React from 'react';

/**
 * Icon — from stripe-dashboard-ds@0.1.0.
 */
export interface IconProps {
  /** Which icon to draw: home, balances, transactions, customers, product, payments, billing, reporting, more, search, plus,  */
  name: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** 16px by default; 'sm' is 12px (inside badges and chips). */
  size?: "sm" | "md";
  /** Accessible label. Omit for decorative icons next to a text label. */
  label?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  /** Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or  */
  ref?: string | ((instance: SVGSVGElement) => void | React.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React.RefObject<SVGSVGElement>;
}

export declare const Icon: React.ComponentType<IconProps>;
