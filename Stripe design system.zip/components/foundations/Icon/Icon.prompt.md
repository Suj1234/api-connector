Icon from stripe-dashboard-ds. Use via `window.StripeDashboard.Icon` (bundle loaded from the root `_ds_bundle.js`).

A 16px, 1.5px-stroke line icon drawn in `currentColor`, matching the dashboard's icon weight.
@category foundations

## Props

```ts
interface IconProps {
  /** Which icon to draw: home, balances, transactions, customers, product, payments, billing, reporting, more, search, plus,  */
  name: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** 16px by default; 'sm' is 12px (inside badges and chips). */
  size?: "sm" | "md";
  /** Accessible label. Omit for decorative icons next to a text label. */
  label?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  /** Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or  */
  ref?: string | ((instance: SVGSVGElement) => void | React.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES[keyof React.DO_NOT_USE_OR_YOU_WILL_BE_FIRED_CALLBACK_REF_RETURN_VALUES]) | React.RefObject<SVGSVGElement>;
}
```

## Examples

### AllIcons

```jsx
() => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 88px)', gap: 12, color: 'var(--gray-600)' }}>
    {NAMES.map((n) => (
      <div key={n} style={{ display: 'grid', justifyItems: 'center', gap: 6, fontSize: 11, color: 'var(--text-muted)' }}>
        <Icon name={n} style={{ color: 'var(--gray-700)' }} />
        {n}
      </div>
    ))}
  </div>
)
```

### InContext

```jsx
() => (
  <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
    <span style={{ color: 'var(--text-link)', display: 'inline-flex', gap: 8, fontWeight: 600 }}><Icon name="transactions" />Transactions</span>
    <span style={{ color: 'var(--green-500)' }}><Icon name="check-circle" label="Succeeded" /></span>
    <span style={{ color: 'var(--red-500)' }}><Icon name="x-circle" label="Failed" /></span>
  </div>
)
```
