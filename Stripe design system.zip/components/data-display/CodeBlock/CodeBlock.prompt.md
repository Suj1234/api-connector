CodeBlock from stripe-dashboard-ds. Use via `window.StripeDashboard.CodeBlock` (bundle loaded from the root `_ds_bundle.js`).

A light monospace panel for request and response bodies, with JSON colouring.
@category data-display

## Props

```ts
interface CodeBlockProps {
  /** A JSON-serialisable value rendered pretty-printed with key/string/number colouring. */
  json?: unknown;
  /** Plain code text (used when json is not given). */
  code?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### ResponseBody

```jsx
() => (
  <div style={{ width: 460 }}>
    <CodeBlock json={{ id: 'note_1QUJENP1CRBSqBJ3', object: 'note', deleted: true }} />
  </div>
)
```

### EventData

```jsx
() => (
  <div style={{ width: 460 }}>
    <CodeBlock json={{ id: 'pi_3QSj4RP1CRBSqBJ31', object: 'payment_intent', amount: 200, amount_capturable: 0, livemode: true, status: 'succeeded' }} />
  </div>
)
```
