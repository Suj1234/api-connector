import * as React from 'react';

/**
 * CodeBlock — from stripe-dashboard-ds@0.1.0.
 */
export interface CodeBlockProps {
  /** A JSON-serialisable value rendered pretty-printed with key/string/number colouring. */
  json?: unknown;
  /** Plain code text (used when json is not given). */
  code?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const CodeBlock: React.ComponentType<CodeBlockProps>;
