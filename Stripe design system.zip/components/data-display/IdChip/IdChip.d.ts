import * as React from 'react';

/**
 * IdChip — from stripe-dashboard-ds@0.1.0.
 */
export interface IdChipProps {
  /** The ID or key, e.g. "pi_3QSj4RP1CRBSqBJ31". */
  value: string;
  /** Makes it a blurple link to the object. */
  href?: string;
  /** Shows a copy button (default true for non-links). */
  copyable?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const IdChip: React.ComponentType<IdChipProps>;
