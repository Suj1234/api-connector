IdChip from stripe-dashboard-ds. Use via `window.StripeDashboard.IdChip` (bundle loaded from the root `_ds_bundle.js`).

An object ID or API key in Menlo 13px with a copy button, or as a blurple link.
@category data-display

## Props

```ts
interface IdChipProps {
  /** The ID or key, e.g. "pi_3QSj4RP1CRBSqBJ31". */
  value: string;
  /** Makes it a blurple link to the object. */
  href?: string;
  /** Shows a copy button (default true for non-links). */
  copyable?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Kinds

```jsx
() => (
  <div style={{ display: 'grid', gap: 8 }}>
    <IdChip value="pi_3QSj4RP1CRBSqBJ31" />
    <IdChip value="cus_RLKFqz6BENCJdI" href="#" />
    <IdChip value="pk_live_51QRP3eP1CRB…" />
  </div>
)
```
