// Re-export of stripe-dashboard-ds@0.1.0 IdChip. Implementation is in the root _ds_bundle.js (window.StripeDashboard).
Object.assign(window, { IdChip: window.StripeDashboard.IdChip });
