EmptyState from stripe-dashboard-ds. Use via `window.StripeDashboard.EmptyState` (bundle loaded from the root `_ds_bundle.js`).

What a list or section shows before it has data: icon, title, one sentence and a create action.
@category data-display

## Props

```ts
interface EmptyStateProps {
  /** Icon in a grey tile (page-level empty states). */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** What's missing, e.g. "No coupons". */
  title?: React.ReactNode;
  /** One sentence on how it fills. */
  description?: React.ReactNode;
  /** A Button or Link, e.g. "+ Create coupon". */
  action?: React.ReactNode;
  /** Dashed box for section-level empties ("No metadata"). */
  boxed?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### PageLevel

```jsx
() => (
  <div style={{ width: 520 }}>
    <EmptyState icon="doc" title="No coupons" description="Create coupons to offer discounts on invoices, subscriptions, or entire customer accounts." action={<Button variant="primary" size="sm" icon="plus">Create coupon</Button>} />
  </div>
)
```

### NoResults

```jsx
() => (
  <div style={{ width: 520 }}>
    <EmptyState icon="search" title="No payments found" description="There aren't any results for that query. Try using different filters." />
  </div>
)
```

### Section

```jsx
() => (
  <div style={{ width: 520, display: 'grid', gap: 12 }}>
    <EmptyState boxed description="No metadata" />
    <EmptyState boxed description="When you add credit notes on this invoice, they will appear here." action={<Link href="#">Learn more</Link>} />
  </div>
)
```
