import * as React from 'react';

/**
 * EmptyState — from stripe-dashboard-ds@0.1.0.
 */
export interface EmptyStateProps {
  /** Icon in a grey tile (page-level empty states). */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** What's missing, e.g. "No coupons". */
  title?: React.ReactNode;
  /** One sentence on how it fills. */
  description?: React.ReactNode;
  /** A Button or Link, e.g. "+ Create coupon". */
  action?: React.ReactNode;
  /** Dashed box for section-level empties ("No metadata"). */
  boxed?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const EmptyState: React.ComponentType<EmptyStateProps>;
