CountTabs from stripe-dashboard-ds. Use via `window.StripeDashboard.CountTabs` (bundle loaded from the root `_ds_bundle.js`).

Bordered status tiles above a list that filter it and show counts (All 6 · Succeeded 1 · Failed 3).
@category data-display

## Props

```ts
interface CountTabsProps {
  /** Tiles in order; "All" first. */
  items: CountTab[];
  /** Selected tile's value (defaults to the first). */
  value?: string;
  /** Called with the clicked tile's value. */
  onChange?: (value: string) => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Transactions

```jsx
() => (
  <div style={{ width: 760 }}>
    <CountTabs items={[{ label: 'All', count: 6 }, { label: 'Succeeded', count: 1 }, { label: 'Refunded', count: 0 }, { label: 'Disputed', count: 0 }, { label: 'Failed', count: 3 }, { label: 'Uncaptured', count: 0 }]} />
  </div>
)
```

### Products

```jsx
() => (
  <div style={{ width: 560 }}>
    <CountTabs value="Active" items={[{ label: 'All', count: 4 }, { label: 'Active', count: 3 }, { label: 'Archived', count: 1 }]} />
  </div>
)
```
