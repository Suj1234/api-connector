import * as React from 'react';

/**
 * CountTabs — from stripe-dashboard-ds@0.1.0.
 */
export interface CountTabsProps {
  /** Tiles in order; "All" first. */
  items: CountTab[];
  /** Selected tile's value (defaults to the first). */
  value?: string;
  /** Called with the clicked tile's value. */
  onChange?: (value: string) => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const CountTabs: React.ComponentType<CountTabsProps>;
