import * as React from 'react';

/**
 * Amount — from stripe-dashboard-ds@0.1.0.
 */
export interface AmountProps {
  /** Formatted value with symbol or code, e.g. "MYR 2.00" or "US$1.00". */
  value: string;
  /** ISO currency code shown after it in grey, e.g. "MYR". */
  currency?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Amount: React.ComponentType<AmountProps>;
