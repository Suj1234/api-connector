Amount from stripe-dashboard-ds. Use via `window.StripeDashboard.Amount` (bundle loaded from the root `_ds_bundle.js`).

A money value in bold followed by its ISO currency code in grey ("MYR 2.00 MYR"), as in tables.
@category data-display

## Props

```ts
interface AmountProps {
  /** Formatted value with symbol or code, e.g. "MYR 2.00" or "US$1.00". */
  value: string;
  /** ISO currency code shown after it in grey, e.g. "MYR". */
  currency?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Currencies

```jsx
() => (
  <div style={{ display: 'grid', gap: 8 }}>
    <Amount value="MYR 2.00" currency="MYR" />
    <Amount value="US$1.00" currency="USD" />
    <Amount value="(MYR 4.00)" currency="MYR" />
  </div>
)
```
