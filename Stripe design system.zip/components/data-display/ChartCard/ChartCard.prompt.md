ChartCard from stripe-dashboard-ds. Use via `window.StripeDashboard.ChartCard` (bundle loaded from the root `_ds_bundle.js`).

A Metric over a single-series line chart with a dashed previous period and a "View more" footer.
@category data-display

## Props

```ts
interface ChartCardProps {
  /** Series values, oldest first. */
  data: number[];
  /** Previous-period series (dashed grey), same length. */
  previous?: number[];
  /** First x-axis label, e.g. "3 Dec". */
  startLabel?: string;
  /** Last x-axis label, e.g. "Today". */
  endLabel?: string;
  /** Label for the top gridline, e.g. "MYR 0.92". */
  maxLabel?: string;
  /** Refresh time for the footer, e.g. "Updated 06:23". */
  updated?: string;
  /** Link text for the footer (defaults to "View more"). */
  moreLabel?: string;
  /** Link target for the footer. */
  moreHref?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  /** Show an info icon after the label. */
  info?: boolean;
  /** KPI name, e.g. "Gross volume". */
  label: React.ReactNode;
  /** Formatted value with currency first, e.g. "MYR 2.00". */
  value: React.ReactNode;
  /** Muted comparison line, e.g. "MYR 0.00 previous period". */
  compare?: React.ReactNode;
  /** Change badge text, e.g. "+0%". */
  delta?: string;
  /** success (default) or danger colouring for the delta. */
  deltaTone?: "neutral" | "success" | "danger";
}
```

## Examples

### NetVolume

```jsx
() => (
  <div style={{ width: 340 }}>
    <ChartCard label="Net volume from sales" delta="+0%" value="MYR 0.92" compare="MYR 0.00 previous period" data={[0, 0, 0, 0.92, 0, 0, 0]} previous={[0, 0, 0, 0, 0, 0, 0]} maxLabel="MYR 0.92" startLabel="3 Dec" endLabel="Today" updated="Updated 06:23" />
  </div>
)
```

### NewCustomers

```jsx
() => (
  <div style={{ width: 340 }}>
    <ChartCard label="New customers" info value="3" compare="0 previous period" data={[0, 0, 1, 0, 0, 1, 3]} previous={[0, 0, 0, 1, 0, 0, 0]} maxLabel="3" startLabel="Jan 2024" endLabel="Dec 2024" updated="Updated 11:17" />
  </div>
)
```
