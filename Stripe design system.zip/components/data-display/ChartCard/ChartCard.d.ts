import * as React from 'react';

/**
 * ChartCard — from stripe-dashboard-ds@0.1.0.
 */
export interface ChartCardProps {
  /** Series values, oldest first. */
  data: number[];
  /** Previous-period series (dashed grey), same length. */
  previous?: number[];
  /** First x-axis label, e.g. "3 Dec". */
  startLabel?: string;
  /** Last x-axis label, e.g. "Today". */
  endLabel?: string;
  /** Label for the top gridline, e.g. "MYR 0.92". */
  maxLabel?: string;
  /** Refresh time for the footer, e.g. "Updated 06:23". */
  updated?: string;
  /** Link text for the footer (defaults to "View more"). */
  moreLabel?: string;
  /** Link target for the footer. */
  moreHref?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  /** Show an info icon after the label. */
  info?: boolean;
  /** KPI name, e.g. "Gross volume". */
  label: React.ReactNode;
  /** Formatted value with currency first, e.g. "MYR 2.00". */
  value: React.ReactNode;
  /** Muted comparison line, e.g. "MYR 0.00 previous period". */
  compare?: React.ReactNode;
  /** Change badge text, e.g. "+0%". */
  delta?: string;
  /** success (default) or danger colouring for the delta. */
  deltaTone?: "neutral" | "success" | "danger";
}

export declare const ChartCard: React.ComponentType<ChartCardProps>;
