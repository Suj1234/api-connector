Table from stripe-dashboard-ds. Use via `window.StripeDashboard.Table` (bundle loaded from the root `_ds_bundle.js`).

The dashboard list table: bold 12px headers, 38px rows, checkbox and overflow columns, em-dash empty cells.
@category data-display

## Props

```ts
interface TableProps {
  /** Column definitions in order. */
  columns: TableColumn<Row>[];
  /** Row data. */
  rows: Row[];
  /** Returns a stable key per row. */
  rowKey: (row: Row, index: number) => string;
  /** Adds a leading checkbox column. */
  selectable?: boolean;
  /** Keys of selected rows (highlighted, checkbox ticked). */
  selectedKeys?: string[];
  /** Called when a row checkbox toggles. */
  onToggleRow?: (key: string) => void;
  /** Adds a trailing "…" overflow button per row. */
  rowActions?: boolean;
  /** Called when a row is clicked. */
  onRowClick?: (row: Row) => void;
  /** Footer content under the table, e.g. a Pagination. */
  footer?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### Payments

```jsx
() => (
  <Table<Payment>
    rows={rows}
    rowKey={(r) => r.id}
    selectable
    selectedKeys={['py_2']}
    rowActions
    columns={[
      { key: 'amount', header: 'Amount', render: (r) => <Amount value={r.amount} currency={r.currency} /> },
      { key: 'status', header: '', render: (r) => statusBadge(r.status) },
      { key: 'method', header: 'Payment method', render: (r) => (r.last4 ? <CardBrand last4={r.last4} /> : null) },
      { key: 'description', header: 'Description' },
      { key: 'customer', header: 'Customer' },
      { key: 'date', header: 'Date' },
    ]}
    footer={<Pagination summary="4 results" hasNext />}
  />
);

type Customer = { id: string; name: string; email: string; spend: string; payments: number; created: string }
```

### Customers

```jsx
() => (
  <Table<Customer>
    rows={[
      { id: 'c1', name: 'Diana Ford', email: 'iamdianaford@gmail.com', spend: 'MYR 0.00', payments: 0, created: '9 Dec, 07:28' },
      { id: 'c2', name: 'Cindy Jung', email: 'itscindyjung@gmail.com', spend: 'MYR 0.00', payments: 0, created: '5 Dec, 19:34' },
      { id: 'c3', name: 'Leonard Kim', email: 'iamleonardkim@gmail.com', spend: 'MYR 2.00', payments: 1, created: '5 Dec, 18:52' },
    ]}
    rowKey={(r) => r.id}
    rowActions
    columns={[
      { key: 'name', header: 'Name', render: (r) => <b style={{ color: 'var(--text)' }}>{r.name}</b> },
      { key: 'email', header: 'Email' },
      { key: 'method', header: 'Default payment method' },
      { key: 'spend', header: 'Total spend', align: 'end' },
      { key: 'payments', header: 'Payments', align: 'end' },
      { key: 'created', header: 'Created' },
    ]}
  />
)
```
