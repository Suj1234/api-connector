import * as React from 'react';

/**
 * Table — from stripe-dashboard-ds@0.1.0.
 * @replaces table
 */
export interface TableProps<Row> {
  /** Column definitions in order. */
  columns: TableColumn<Row>[];
  /** Row data. */
  rows: Row[];
  /** Returns a stable key per row. */
  rowKey: (row: Row, index: number) => string;
  /** Adds a leading checkbox column. */
  selectable?: boolean;
  /** Keys of selected rows (highlighted, checkbox ticked). */
  selectedKeys?: string[];
  /** Called when a row checkbox toggles. */
  onToggleRow?: (key: string) => void;
  /** Adds a trailing "…" overflow button per row. */
  rowActions?: boolean;
  /** Called when a row is clicked. */
  onRowClick?: (row: Row) => void;
  /** Footer content under the table, e.g. a Pagination. */
  footer?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Table: React.ComponentType<TableProps>;
