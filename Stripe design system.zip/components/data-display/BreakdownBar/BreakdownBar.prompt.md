BreakdownBar from stripe-dashboard-ds. Use via `window.StripeDashboard.BreakdownBar` (bundle loaded from the root `_ds_bundle.js`).

A segmented 8px status bar with a legend of labelled values (payments or invoices by status).
@category data-display

## Props

```ts
interface BreakdownBarProps {
  /** Segments in legend order. */
  segments: BreakdownSegment[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Payments

```jsx
() => (
  <Card title="Payments" info style={{ width: 340 }}>
    <BreakdownBar segments={[
      { label: 'Succeeded', value: 2, display: 'MYR 2.00', color: 'purple-400' },
      { label: 'Uncaptured', value: 0, display: 'MYR 0.00', color: 'blue-700' },
      { label: 'Refunded', value: 0, display: 'MYR 0.00', color: 'green-500' },
      { label: 'Failed', value: 6, display: 'MYR 6.00', color: 'orange-600' },
    ]} />
  </Card>
)
```

### Invoices

```jsx
() => (
  <Card title="Invoices" info style={{ width: 340 }}>
    <BreakdownBar segments={[
      { label: 'Draft', value: 0, display: 'MYR 0.00', color: 'gray-150' },
      { label: 'Open', value: 8.88, display: 'MYR 8.88', color: 'blue-700' },
      { label: 'Paid', value: 0, display: 'MYR 0.00', color: 'green-500' },
      { label: 'Uncollectible', value: 0, display: 'MYR 0.00', color: 'orange-600' },
    ]} />
  </Card>
)
```
