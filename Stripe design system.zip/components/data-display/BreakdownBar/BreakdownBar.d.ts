import * as React from 'react';

/**
 * BreakdownBar — from stripe-dashboard-ds@0.1.0.
 */
export interface BreakdownBarProps {
  /** Segments in legend order. */
  segments: BreakdownSegment[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const BreakdownBar: React.ComponentType<BreakdownBarProps>;
