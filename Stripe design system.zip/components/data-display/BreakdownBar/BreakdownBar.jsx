// Re-export of stripe-dashboard-ds@0.1.0 BreakdownBar. Implementation is in the root _ds_bundle.js (window.StripeDashboard).
Object.assign(window, { BreakdownBar: window.StripeDashboard.BreakdownBar });
