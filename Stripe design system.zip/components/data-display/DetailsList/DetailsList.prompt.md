DetailsList from stripe-dashboard-ds. Use via `window.StripeDashboard.DetailsList` (bundle loaded from the root `_ds_bundle.js`).

Label/value pairs describing one object, stacked (details rail) or in two columns (summary).
@category data-display

## Props

```ts
interface DetailsListProps {
  /** Pairs in display order. */
  items: DetailsItem[];
  /** stacked = label above value (right "Details" rail); rows = label left, value right (summaries). */
  layout?: "stacked" | "rows";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### DetailsRail

```jsx
() => (
  <div style={{ width: 280 }}>
    <DetailsList items={[
      { label: 'Payment ID', value: <IdChip value="pi_3QSj4RP1CRBSq" /> },
      { label: 'Statement descriptor', value: 'CONTENT-MOBBIN.COM' },
      { label: 'Last updated', value: '6 Dec, 00:43' },
      { label: 'Risk evaluation', value: <Badge tone="success">Normal</Badge> },
    ]} />
  </div>
)
```

### SummaryRows

```jsx
() => (
  <div style={{ width: 460 }}>
    <DetailsList layout="rows" items={[
      { label: 'Customer', value: <Link href="#">Cindy Jung</Link> },
      { label: 'Created', value: '5 Dec, 20:00' },
      { label: 'Current period', value: '5 Dec to 19 Dec' },
      { label: 'Discounts', value: null },
      { label: 'Billing method', value: 'Send invoice' },
    ]} />
  </div>
)
```
