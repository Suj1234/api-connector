import * as React from 'react';

/**
 * DetailsList — from stripe-dashboard-ds@0.1.0.
 */
export interface DetailsListProps {
  /** Pairs in display order. */
  items: DetailsItem[];
  /** stacked = label above value (right "Details" rail); rows = label left, value right (summaries). */
  layout?: "stacked" | "rows";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const DetailsList: React.ComponentType<DetailsListProps>;
