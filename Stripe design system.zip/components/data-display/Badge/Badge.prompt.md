Badge from stripe-dashboard-ds. Use via `window.StripeDashboard.Badge` (bundle loaded from the root `_ds_bundle.js`).

The tinted status pill shown after amounts and titles: Succeeded, Failed, Open, Pending, Draft.
@category data-display

## Props

```ts
interface BadgeProps {
  /** success (Succeeded, Active, Paid, 200 OK) · danger (Failed, Blocked) · info (Open, Default, Trial) · warning (Pending, E */
  tone?: "neutral" | "success" | "danger" | "info" | "warning";
  /** Trailing status icon, e.g. 'check', 'x', 'clock'. */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Statuses

```jsx
() => (
  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
    <Badge tone="success" icon="check">Succeeded</Badge>
    <Badge tone="danger" icon="x">Failed</Badge>
    <Badge icon="clock">Incomplete</Badge>
    <Badge tone="info">Open</Badge>
    <Badge tone="warning">Pending</Badge>
    <Badge>Draft</Badge>
  </div>
)
```

### Contextual

```jsx
() => (
  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
    <Badge tone="success">Active</Badge>
    <Badge tone="info">Trial ends 19 Dec</Badge>
    <Badge tone="success">200 OK</Badge>
    <Badge tone="success">+0%</Badge>
    <Badge>Withdrawn</Badge>
    <Badge>Archived</Badge>
  </div>
)
```
