import * as React from 'react';

/**
 * Badge — from stripe-dashboard-ds@0.1.0.
 */
export interface BadgeProps {
  /** success (Succeeded, Active, Paid, 200 OK) · danger (Failed, Blocked) · info (Open, Default, Trial) · warning (Pending, E */
  tone?: "neutral" | "success" | "danger" | "info" | "warning";
  /** Trailing status icon, e.g. 'check', 'x', 'clock'. */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Badge: React.ComponentType<BadgeProps>;
