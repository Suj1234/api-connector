Tag from stripe-dashboard-ds. Use via `window.StripeDashboard.Tag` (bundle loaded from the root `_ds_bundle.js`).

A 16px label beside a field or feature name: New, Optional, Recommended, Default.
@category data-display

## Props

```ts
interface TagProps {
  /** brand = "New" (filled blurple) · neutral = "Optional", "Recommended" · info = "Default", "Live mode" · danger = "Less se */
  tone?: "neutral" | "danger" | "info" | "brand";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Tones

```jsx
() => (
  <div style={{ display: 'flex', gap: 8 }}>
    <Tag tone="brand">New</Tag><Tag>Optional</Tag><Tag>Recommended</Tag><Tag tone="info">Default</Tag><Tag tone="danger">Less secure</Tag>
  </div>
)
```

### BesideLabel

```jsx
() => (
  <div style={{ display: 'flex', gap: 6, alignItems: 'center', fontWeight: 600 }}>Invoice template <Tag tone="brand">New</Tag></div>
)
```
