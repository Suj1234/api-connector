import * as React from 'react';

/**
 * Tag — from stripe-dashboard-ds@0.1.0.
 */
export interface TagProps {
  /** brand = "New" (filled blurple) · neutral = "Optional", "Recommended" · info = "Default", "Live mode" · danger = "Less se */
  tone?: "neutral" | "danger" | "info" | "brand";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Tag: React.ComponentType<TagProps>;
