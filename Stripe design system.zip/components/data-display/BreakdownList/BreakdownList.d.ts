import * as React from 'react';

/**
 * BreakdownList — from stripe-dashboard-ds@0.1.0.
 */
export interface BreakdownListProps {
  /** Money lines; the last one is the total and renders bold. */
  items: { label: React.ReactNode; value: React.ReactNode; }[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const BreakdownList: React.ComponentType<BreakdownListProps>;
