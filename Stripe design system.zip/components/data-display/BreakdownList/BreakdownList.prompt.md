BreakdownList from stripe-dashboard-ds. Use via `window.StripeDashboard.BreakdownList` (bundle loaded from the root `_ds_bundle.js`).

Money lines with dividers and a bold total last: Payment amount, Stripe processing fees, Net amount.
@category data-display

## Props

```ts
interface BreakdownListProps {
  /** Money lines; the last one is the total and renders bold. */
  items: { label: React.ReactNode; value: React.ReactNode; }[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### PaymentBreakdown

```jsx
() => (
  <div style={{ width: 460 }}>
    <BreakdownList items={[
      { label: 'Payment amount', value: 'MYR 2.00 MYR' },
      { label: <Hint>Stripe processing fees</Hint>, value: '−MYR 1.08 MYR' },
      { label: 'Net amount', value: 'MYR 0.92 MYR' },
    ]} />
  </div>
)
```

### InvoiceTotals

```jsx
() => (
  <div style={{ width: 320 }}>
    <BreakdownList items={[
      { label: 'Subtotal', value: 'US$1.00' },
      { label: 'Total excluding tax', value: 'US$1.00' },
      { label: 'Amount due', value: 'US$1.00' },
    ]} />
  </div>
)
```
