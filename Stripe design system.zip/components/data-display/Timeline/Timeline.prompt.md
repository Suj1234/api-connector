Timeline from stripe-dashboard-ds. Use via `window.StripeDashboard.Timeline` (bundle loaded from the root `_ds_bundle.js`).

A vertical event history with status nodes on a hairline spine.
@category data-display

## Props

```ts
interface TimelineProps {
  /** Events, newest first. */
  items: TimelineItem[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Payment

```jsx
() => (
  <div style={{ width: 460 }}>
    <Timeline items={[
      { title: 'MYR 0.50 refund attempted but failed', time: '9 Dec 2024, 07:37', tone: 'danger', children: <Link href="#">View details</Link> },
      { title: 'Payment succeeded', time: '6 Dec 2024, 00:42', tone: 'success' },
      { title: 'Payment started', time: '6 Dec 2024, 00:42' },
    ]} />
  </div>
)
```

### CustomerActivity

```jsx
() => (
  <div style={{ width: 460 }}>
    <Timeline items={[
      { title: <>Subscribed to <Link href="#">Yearly plan for promotion</Link></>, time: '9 Dec 2024, 07:32', tone: 'success' },
      { title: 'Customer was created', time: '5 Dec 2024, 18:52', icon: 'customers' },
    ]} />
  </div>
)
```
