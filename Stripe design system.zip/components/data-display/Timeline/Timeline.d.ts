import * as React from 'react';

/**
 * Timeline — from stripe-dashboard-ds@0.1.0.
 */
export interface TimelineProps {
  /** Events, newest first. */
  items: TimelineItem[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Timeline: React.ComponentType<TimelineProps>;
