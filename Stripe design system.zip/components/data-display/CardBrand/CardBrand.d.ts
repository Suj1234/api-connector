import * as React from 'react';

/**
 * CardBrand — from stripe-dashboard-ds@0.1.0.
 */
export interface CardBrandProps {
  /** Card network label shown in the chip. */
  brand?: "VISA" | "MC" | "AMEX";
  /** Last four digits, shown as "•••• 6442". */
  last4?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const CardBrand: React.ComponentType<CardBrandProps>;
