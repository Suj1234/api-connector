CardBrand from stripe-dashboard-ds. Use via `window.StripeDashboard.CardBrand` (bundle loaded from the root `_ds_bundle.js`).

A payment-method cell: a small card-network chip followed by the masked last four digits.
@category data-display

## Props

```ts
interface CardBrandProps {
  /** Card network label shown in the chip. */
  brand?: "VISA" | "MC" | "AMEX";
  /** Last four digits, shown as "•••• 6442". */
  last4?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Cards

```jsx
() => (
  <div style={{ display: 'grid', gap: 8 }}>
    <CardBrand last4="6442" />
    <CardBrand brand="MC" last4="0687" />
    <CardBrand brand="AMEX" last4="3785" />
  </div>
)
```
