Metric from stripe-dashboard-ds. Use via `window.StripeDashboard.Metric` (bundle loaded from the root `_ds_bundle.js`).

A KPI block: label with optional delta badge, a 20px value, and a comparison line.
@category data-display

## Props

```ts
interface MetricProps {
  /** KPI name, e.g. "Gross volume". */
  label: React.ReactNode;
  /** Formatted value with currency first, e.g. "MYR 2.00". */
  value: React.ReactNode;
  /** Muted comparison line, e.g. "MYR 0.00 previous period". */
  compare?: React.ReactNode;
  /** Change badge text, e.g. "+0%". */
  delta?: string;
  /** success (default) or danger colouring for the delta. */
  deltaTone?: "neutral" | "success" | "danger";
  /** Show an info icon after the label. */
  info?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### WithDelta

```jsx
() => (
  <Metric label="Gross volume" info delta="+0%" value="MYR 2.00" compare="MYR 0.00 previous period" />
)
```

### Balance

```jsx
() => (
  <div style={{ display: 'flex', gap: 48 }}>
    <Metric label="MYR balance" value="MYR 0.92" compare="Available to pay out" />
    <Metric label="Payouts" value="MYR 5.00" compare="Expected 13 Jan" />
  </div>
)
```

### Decline

```jsx
() => (
  <Metric label="Net volume from sales" info delta="−12%" deltaTone="danger" value="−MYR 0.08" compare="MYR 0.00 previous period" />
)
```
