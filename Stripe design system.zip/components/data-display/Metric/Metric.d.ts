import * as React from 'react';

/**
 * Metric — from stripe-dashboard-ds@0.1.0.
 */
export interface MetricProps {
  /** KPI name, e.g. "Gross volume". */
  label: React.ReactNode;
  /** Formatted value with currency first, e.g. "MYR 2.00". */
  value: React.ReactNode;
  /** Muted comparison line, e.g. "MYR 0.00 previous period". */
  compare?: React.ReactNode;
  /** Change badge text, e.g. "+0%". */
  delta?: string;
  /** success (default) or danger colouring for the delta. */
  deltaTone?: "neutral" | "success" | "danger";
  /** Show an info icon after the label. */
  info?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Metric: React.ComponentType<MetricProps>;
