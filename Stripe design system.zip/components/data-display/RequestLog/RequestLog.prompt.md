RequestLog from stripe-dashboard-ds. Use via `window.StripeDashboard.RequestLog` (bundle loaded from the root `_ds_bundle.js`).

API request rows: status badge, method and path in monospace, time at the right.
@category data-display

## Props

```ts
interface RequestLogProps {
  /** Newest first. */
  entries: RequestLogEntry[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Logs

```jsx
() => (
  <div style={{ width: 560 }}>
    <RequestLog entries={[
      { status: 200, method: 'DELETE', path: '/v1/notes/note_1QUJENP1CRBSq', time: '09:31:42' },
      { status: 200, method: 'POST', path: '/v1/notes', time: '09:31:20' },
      { status: 200, method: 'POST', path: '/v1/payment_intents', time: '09:24:07' },
      { status: 402, method: 'POST', path: '/v1/charges/ch_3QSj4R/refund', time: '07:37:23' },
    ]} />
  </div>
)
```
