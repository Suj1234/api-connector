import * as React from 'react';

/**
 * RequestLog — from stripe-dashboard-ds@0.1.0.
 */
export interface RequestLogProps {
  /** Newest first. */
  entries: RequestLogEntry[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const RequestLog: React.ComponentType<RequestLogProps>;
