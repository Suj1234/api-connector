MenuSeparator from stripe-dashboard-ds. Use via `window.StripeDashboard.MenuSeparator` (bundle loaded from the root `_ds_bundle.js`).

A 1px divider between groups in a Menu.
@category actions

## Props

```ts
interface MenuSeparatorProps {
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### BetweenGroups

```jsx
() => (
  <Menu style={{ width: 200 }}>
    <MenuItem tone="neutral" icon="gear">Settings</MenuItem>
    <MenuItem tone="neutral" icon="customers">Profile</MenuItem>
    <MenuSeparator />
    <MenuItem tone="neutral">Sign out</MenuItem>
  </Menu>
)
```
