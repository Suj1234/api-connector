import * as React from 'react';

/**
 * MenuSeparator — from stripe-dashboard-ds@0.1.0.
 */
export interface MenuSeparatorProps {
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const MenuSeparator: React.ComponentType<MenuSeparatorProps>;
