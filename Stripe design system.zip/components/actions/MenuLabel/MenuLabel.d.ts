import * as React from 'react';

/**
 * MenuLabel — from stripe-dashboard-ds@0.1.0.
 */
export interface MenuLabelProps {
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const MenuLabel: React.ComponentType<MenuLabelProps>;
