MenuLabel from stripe-dashboard-ds. Use via `window.StripeDashboard.MenuLabel` (bundle loaded from the root `_ds_bundle.js`).

A small grey group heading inside a Menu.
@category actions

## Props

```ts
interface MenuLabelProps {
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Grouped

```jsx
() => (
  <Menu style={{ width: 220 }}>
    <MenuLabel>Manage payouts</MenuLabel>
    <MenuItem>Manage payout schedule</MenuItem>
    <MenuItem>Manage bank accounts</MenuItem>
  </Menu>
)
```
