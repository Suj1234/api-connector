import * as React from 'react';

/**
 * MenuItem — from stripe-dashboard-ds@0.1.0.
 */
export interface MenuItemProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name (required for icon-only controls). */
  "aria-label"?: string;
  /** action (blurple, default) for commands; neutral for navigation lists; danger (red) for destructive items, placed last. */
  tone?: "neutral" | "danger" | "action";
  /** Leading icon. */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Shortcut chip at the right edge, e.g. "C I". */
  shortcut?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const MenuItem: React.ComponentType<MenuItemProps>;
