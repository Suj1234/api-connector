// Re-export of stripe-dashboard-ds@0.1.0 MenuItem. Implementation is in the root _ds_bundle.js (window.StripeDashboard).
Object.assign(window, { MenuItem: window.StripeDashboard.MenuItem });
