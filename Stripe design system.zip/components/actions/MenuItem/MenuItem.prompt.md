MenuItem from stripe-dashboard-ds. Use via `window.StripeDashboard.MenuItem` (bundle loaded from the root `_ds_bundle.js`).

One row of a Menu.
@category actions

## Props

```ts
interface MenuItemProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name (required for icon-only controls). */
  "aria-label"?: string;
  /** action (blurple, default) for commands; neutral for navigation lists; danger (red) for destructive items, placed last. */
  tone?: "neutral" | "danger" | "action";
  /** Leading icon. */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Shortcut chip at the right edge, e.g. "C I". */
  shortcut?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Tones

```jsx
() => (
  <Menu style={{ width: 220 }}>
    <MenuItem>Refund payment</MenuItem>
    <MenuItem tone="neutral" icon="gear">Settings</MenuItem>
    <MenuItem tone="neutral" icon="billing" shortcut="C I">Invoice</MenuItem>
    <MenuItem tone="danger">Add to block list</MenuItem>
  </Menu>
)
```

### Disabled

```jsx
() => (
  <Menu style={{ width: 220 }}>
    <MenuItem>Send receipt</MenuItem>
    <MenuItem disabled style={{ color: 'var(--text-placeholder)' }}>Cancel refund</MenuItem>
  </Menu>
)
```
