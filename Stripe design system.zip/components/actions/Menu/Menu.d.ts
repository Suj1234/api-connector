import * as React from 'react';

/**
 * Menu — from stripe-dashboard-ds@0.1.0.
 */
export interface MenuProps {
  /** MenuItem, MenuLabel and MenuSeparator elements. */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Menu: React.ComponentType<MenuProps>;
