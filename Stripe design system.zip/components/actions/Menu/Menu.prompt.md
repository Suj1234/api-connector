Menu from stripe-dashboard-ds. Use via `window.StripeDashboard.Menu` (bundle loaded from the root `_ds_bundle.js`).

A popover action list (overflow "…" menus, split buttons, quick create). Compose with MenuItem, MenuLabel, MenuSeparator.
@category actions

## Props

```ts
interface MenuProps {
  /** MenuItem, MenuLabel and MenuSeparator elements. */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### RowActions

```jsx
() => (
  <Menu style={{ width: 200 }}>
    <MenuItem>Pin to the top</MenuItem>
    <MenuItem>Edit</MenuItem>
    <MenuSeparator />
    <MenuItem tone="danger">Delete</MenuItem>
  </Menu>
)
```

### QuickCreate

```jsx
() => (
  <Menu style={{ width: 240 }}>
    <MenuLabel>Online payments</MenuLabel>
    <MenuItem tone="neutral" icon="billing" shortcut="C I">Invoice</MenuItem>
    <MenuItem tone="neutral" icon="transactions" shortcut="C S">Subscription</MenuItem>
    <MenuItem tone="neutral" icon="payments" shortcut="C L">Payment link</MenuItem>
    <MenuSeparator />
    <MenuLabel>Balances</MenuLabel>
    <MenuItem tone="neutral" icon="balances" shortcut="C O">Payout</MenuItem>
  </Menu>
)
```

### ProductActions

```jsx
() => (
  <Menu style={{ width: 180 }}>
    <MenuItem>Edit product</MenuItem>
    <MenuItem>Archive product</MenuItem>
    <MenuItem tone="danger">Delete product</MenuItem>
  </Menu>
)
```

## Related

`MenuItem`, `MenuLabel`, `MenuSeparator`
