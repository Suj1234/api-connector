Link from stripe-dashboard-ds. Use via `window.StripeDashboard.Link` (bundle loaded from the root `_ds_bundle.js`).

Inline blurple link, weight 600, no underline. For object references, "View more", docs.
@category actions

## Props

```ts
interface LinkProps {
  /** Link target. */
  href?: string;
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLAnchorElement>;
  /** Adds the external-link icon (docs, other sites). */
  external?: boolean;
  /** Adds a trailing arrow ("Start →", "View more →"). */
  arrow?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### InSentence

```jsx
() => (
  <p style={{ margin: 0 }}>Charged to <Link href="#">Leonard Kim</Link></p>
)
```

### WithIcons

```jsx
() => (
  <div style={{ display: 'flex', gap: 20 }}>
    <Link href="#" arrow>Start</Link>
    <Link href="#" arrow>View more</Link>
    <Link href="#" external>View docs</Link>
  </div>
)
```
