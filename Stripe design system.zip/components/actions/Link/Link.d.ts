import * as React from 'react';

/**
 * Link — from stripe-dashboard-ds@0.1.0.
 * @replaces a
 */
export interface LinkProps {
  /** Link target. */
  href?: string;
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLAnchorElement>;
  /** Adds the external-link icon (docs, other sites). */
  external?: boolean;
  /** Adds a trailing arrow ("Start →", "View more →"). */
  arrow?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Link: React.ComponentType<LinkProps>;
