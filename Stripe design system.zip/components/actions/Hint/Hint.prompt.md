Hint from stripe-dashboard-ds. Use via `window.StripeDashboard.Hint` (bundle loaded from the root `_ds_bundle.js`).

A term with a dashed underline that opens an explanation; keeps the surrounding text colour.
@category actions

## Props

```ts
interface HintProps {
  /** The term that has an explanation, e.g. "Stripe processing fees". */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### FeeTerm

```jsx
() => (
  <div style={{ display: 'flex', justifyContent: 'space-between', width: 360 }}>
    <span><Hint>Stripe processing fees</Hint> <Link href="#">Learn more</Link></span>
    <span>−MYR 1.08</span>
  </div>
)
```
