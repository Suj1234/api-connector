import * as React from 'react';

/**
 * Hint — from stripe-dashboard-ds@0.1.0.
 */
export interface HintProps {
  /** The term that has an explanation, e.g. "Stripe processing fees". */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Hint: React.ComponentType<HintProps>;
