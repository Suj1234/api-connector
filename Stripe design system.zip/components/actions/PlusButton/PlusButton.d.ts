import * as React from 'react';

/**
 * PlusButton — from stripe-dashboard-ds@0.1.0.
 */
export interface PlusButtonProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name, defaults to "Create". */
  "aria-label"?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const PlusButton: React.ComponentType<PlusButtonProps>;
