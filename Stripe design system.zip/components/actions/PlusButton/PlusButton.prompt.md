PlusButton from stripe-dashboard-ds. Use via `window.StripeDashboard.PlusButton` (bundle loaded from the root `_ds_bundle.js`).

The round blurple quick-create button at the right of the top bar.
@category actions

## Props

```ts
interface PlusButtonProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name, defaults to "Create". */
  "aria-label"?: string;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### QuickCreate

```jsx
() => (
  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
    <PlusButton aria-label="Create" />
    <Tooltip shortcut="C">Create</Tooltip>
  </div>
)
```
