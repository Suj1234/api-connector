import * as React from 'react';

/**
 * Button — from stripe-dashboard-ds@0.1.0.
 * @replaces button
 */
export interface ButtonProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name (required for icon-only controls). */
  "aria-label"?: string;
  /** primary = the one main action per view; secondary (default) = everything else; danger = irreversible confirm; ghost = ic */
  variant?: "danger" | "primary" | "secondary" | "ghost" | "link";
  /** sm 28px (cards, toolbars), md 32px (default), lg 40px (auth and onboarding). */
  size?: "sm" | "md" | "lg";
  /** Leading icon. With no children the button becomes square and icon-only (pass aria-label). */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Trailing icon, e.g. 'arrow-right' or 'chev-down'. */
  iconEnd?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Keyboard shortcut shown in a chip after the label, e.g. "⌘ ↵". */
  shortcut?: string;
  /** Stretch to the container width. */
  block?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Button: React.ComponentType<ButtonProps>;
