Button from stripe-dashboard-ds. Use via `window.StripeDashboard.Button` (bundle loaded from the root `_ds_bundle.js`).

The dashboard button: blurple primary, white bordered secondary, red danger, ghost and link variants.
@category actions

## Props

```ts
interface ButtonProps {
  /** Click handler. */
  onClick?: React.MouseEventHandler<HTMLButtonElement>;
  /** Disables the control. */
  disabled?: boolean;
  /** Accessible name (required for icon-only controls). */
  "aria-label"?: string;
  /** primary = the one main action per view; secondary (default) = everything else; danger = irreversible confirm; ghost = ic */
  variant?: "danger" | "primary" | "secondary" | "ghost" | "link";
  /** sm 28px (cards, toolbars), md 32px (default), lg 40px (auth and onboarding). */
  size?: "sm" | "md" | "lg";
  /** Leading icon. With no children the button becomes square and icon-only (pass aria-label). */
  icon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Trailing icon, e.g. 'arrow-right' or 'chev-down'. */
  iconEnd?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Keyboard shortcut shown in a chip after the label, e.g. "⌘ ↵". */
  shortcut?: string;
  /** Stretch to the container width. */
  block?: boolean;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Variants

```jsx
() => (
  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
    <Button variant="primary" icon="plus">Create payment</Button>
    <Button icon="reporting">Analyse</Button>
    <Button variant="danger">Delete customer</Button>
    <Button variant="link" iconEnd="arrow-right">View more</Button>
  </div>
)
```

### WithShortcut

```jsx
() => (
  <div style={{ display: 'flex', gap: 8 }}>
    <Button shortcut="esc">Cancel</Button>
    <Button variant="primary" shortcut="⌘ ↵">Refund MYR 0.50</Button>
  </div>
)
```

### SmallToolbar

```jsx
() => (
  <div style={{ display: 'flex', gap: 8 }}>
    <Button size="sm" icon="export">Export</Button>
    <Button size="sm" icon="gear">Edit columns</Button>
    <Button size="sm" icon="dots" aria-label="More actions" />
  </div>
)
```

### Disabled

```jsx
() => (
  <div style={{ display: 'flex', gap: 8 }}>
    <Button variant="primary" disabled>Continue</Button>
    <Button disabled>Refund</Button>
  </div>
)
```

### FullWidth

```jsx
() => (
  <div style={{ width: 320 }}>
    <Button variant="primary" size="lg" block>Create account</Button>
  </div>
)
```
