import * as React from 'react';

/**
 * Kbd — from stripe-dashboard-ds@0.1.0.
 */
export interface KbdProps {
  /** The keys, e.g. "⌘ ↵" or "esc". */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const Kbd: React.ComponentType<KbdProps>;
