Kbd from stripe-dashboard-ds. Use via `window.StripeDashboard.Kbd` (bundle loaded from the root `_ds_bundle.js`).

A small keyboard-shortcut chip used inside buttons, menus and tooltips.
@category actions

## Props

```ts
interface KbdProps {
  /** The keys, e.g. "⌘ ↵" or "esc". */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### Shortcuts

```jsx
() => (
  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
    <Kbd>⌘ ↵</Kbd><Kbd>esc</Kbd><Kbd>⌘ ⌥ L</Kbd><Kbd>C I</Kbd>
  </div>
)
```
