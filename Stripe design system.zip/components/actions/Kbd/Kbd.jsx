// Re-export of stripe-dashboard-ds@0.1.0 Kbd. Implementation is in the root _ds_bundle.js (window.StripeDashboard).
Object.assign(window, { Kbd: window.StripeDashboard.Kbd });
