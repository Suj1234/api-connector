SectionTitle from stripe-dashboard-ds. Use via `window.StripeDashboard.SectionTitle` (bundle loaded from the root `_ds_bundle.js`).

A 20px bold in-page section heading with a rule under it and an optional action.
@category layout

## Props

```ts
interface SectionTitleProps {
  /** Section name, e.g. "Payment breakdown". */
  children: React.ReactNode;
  /** Small action on the right, e.g. an "Add note" Button. */
  action?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### WithAction

```jsx
() => <div style={{ width: 640 }}><SectionTitle action={<Button size="sm" icon="plus">Add note</Button>}>Timeline</SectionTitle></div>
```

### Plain

```jsx
() => <div style={{ width: 640 }}><SectionTitle>Payment breakdown</SectionTitle></div>
```
