// Re-export of stripe-dashboard-ds@0.1.0 AuthLayout. Implementation is in the root _ds_bundle.js (window.StripeDashboard).
Object.assign(window, { AuthLayout: window.StripeDashboard.AuthLayout });
