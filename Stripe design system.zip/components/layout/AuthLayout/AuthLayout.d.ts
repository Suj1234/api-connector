import * as React from 'react';

/**
 * AuthLayout — from stripe-dashboard-ds@0.1.0.
 */
export interface AuthLayoutProps {
  /** Card title, e.g. "Reset your password". */
  title: React.ReactNode;
  /** Wordmark text top-left (plain type; no logo is shipped). */
  wordmark?: string;
  /** Alternate-route strip at the bottom, e.g. "New to Stripe? <Link>Create account</Link>". */
  footer?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const AuthLayout: React.ComponentType<AuthLayoutProps>;
