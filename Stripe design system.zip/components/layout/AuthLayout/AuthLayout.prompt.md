AuthLayout from stripe-dashboard-ds. Use via `window.StripeDashboard.AuthLayout` (bundle loaded from the root `_ds_bundle.js`).

Sign-in and sign-up screens: a white card over the skewed yellow-red-purple-cyan gradient band.
@category layout

## Props

```ts
interface AuthLayoutProps {
  /** Card title, e.g. "Reset your password". */
  title: React.ReactNode;
  /** Wordmark text top-left (plain type; no logo is shipped). */
  wordmark?: string;
  /** Alternate-route strip at the bottom, e.g. "New to Stripe? <Link>Create account</Link>". */
  footer?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### ResetPassword

```jsx
() => (
  <div style={{ width: 760 }}>
    <AuthLayout title="Reset your password" footer={<>New to Stripe? <Link href="#">Create account</Link></>}>
      <p style={{ margin: 0, color: 'var(--text-subdued)' }}>Enter the email address associated with your account, and we'll send you a link to reset your password.</p>
      <Field label="Email" htmlFor="auth-email"><TextInput id="auth-email" size="lg" type="email" defaultValue="samlee@content-mobbin.com" /></Field>
      <Button variant="primary" size="lg" block>Continue</Button>
      <Link href="#" style={{ textAlign: 'center' }}>Return to sign in</Link>
    </AuthLayout>
  </div>
)
```

### CreateAccount

```jsx
() => (
  <div style={{ width: 760 }}>
    <AuthLayout title="Create your Stripe account" footer={<>Already have an account? <Link href="#">Sign in</Link></>}>
      <Field label="Email" htmlFor="ca-email"><TextInput id="ca-email" size="lg" defaultValue="samlee@content-mobbin.com" /></Field>
      <Field label="Full name" htmlFor="ca-name"><TextInput id="ca-name" size="lg" defaultValue="Sam Lee" /></Field>
      <Field label="Password" htmlFor="ca-pw"><TextInput id="ca-pw" size="lg" type="password" defaultValue="correct-horse-battery" /><PasswordStrength level={4} /></Field>
      <Button variant="primary" size="lg" block>Create account</Button>
    </AuthLayout>
  </div>
)
```
