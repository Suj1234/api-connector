import * as React from 'react';

/**
 * AppShell — from stripe-dashboard-ds@0.1.0.
 */
export interface AppShellProps {
  /** A Sidebar element. */
  sidebar: React.ReactNode;
  /** A TopBar element. */
  topBar: React.ReactNode;
  /** Shows the orange TestModeBar above everything. */
  testMode?: boolean;
  /** Page content (PageHeader, sections...). */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}

export declare const AppShell: React.ComponentType<AppShellProps>;
