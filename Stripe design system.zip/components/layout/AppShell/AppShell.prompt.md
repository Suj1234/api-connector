AppShell from stripe-dashboard-ds. Use via `window.StripeDashboard.AppShell` (bundle loaded from the root `_ds_bundle.js`).

The full dashboard frame: optional test-mode bar, left Sidebar, TopBar and a padded page area.
@category layout

## Props

```ts
interface AppShellProps {
  /** A Sidebar element. */
  sidebar: React.ReactNode;
  /** A TopBar element. */
  topBar: React.ReactNode;
  /** Shows the orange TestModeBar above everything. */
  testMode?: boolean;
  /** Page content (PageHeader, sections...). */
  children: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
}
```

## Examples

### TransactionsPage

```jsx
() => (
  <div style={{ width: 840, height: 600, overflow: 'hidden' }}>
    <AppShell
      testMode
      sidebar={<Sidebar accountName="Content-mobbin" accountInitials="CM" sections={[
  { items: [
    { label: 'Home', icon: 'home' },
    { label: 'Balances', icon: 'balances' },
    { label: 'Transactions', icon: 'transactions', current: true },
    { label: 'Customers', icon: 'customers' },
    { label: 'Product catalogue', icon: 'product' },
  ] },
  { label: 'Shortcuts', items: [{ label: 'Invoices', icon: 'clock' }] },
  { label: 'Products', items: [
    { label: 'Payments', icon: 'payments', expandable: true },
    { label: 'Billing', icon: 'billing', children: [{ label: 'Overview' }, { label: 'Subscriptions' }, { label: 'Invoices' }] },
    { label: 'Reporting', icon: 'reporting', expandable: true },
    { label: 'More', icon: 'more', expandable: true },
  ] },
]} />}
      topBar={<TopBar testMode unread />}
    >
      <PageHeader title="Transactions" actions={<><Button variant="primary" icon="plus">Create payment</Button><Button icon="reporting">Analyse</Button></>} />
      <Banner actions={<Link href="#">Install Xero</Link>} onDismiss={() => {}}><b>Recommendation</b>&nbsp; Get quick financial insights with the Xero app.</Banner>
      <CountTabs items={[{ label: 'All', count: 6 }, { label: 'Succeeded', count: 1 }, { label: 'Failed', count: 3 }]} />
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><FilterChip label="Date and time" /><FilterChip label="Amount" /><FilterChip label="Status" /><FilterChip label="More filters" /></div>
    </AppShell>
  </div>
)
```
