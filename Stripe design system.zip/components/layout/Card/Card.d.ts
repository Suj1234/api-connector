import * as React from 'react';

/**
 * Card — from stripe-dashboard-ds@0.1.0.
 */
export interface CardProps {
  /** Card title (16px bold). */
  title?: React.ReactNode;
  /** Info icon after the title. */
  info?: boolean;
  /** Top-right control, e.g. a close x or small Button. */
  action?: React.ReactNode;
  /** default (bordered), subdued (grey panel, no border) or selected (blurple border). */
  tone?: "default" | "subdued" | "selected";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Card: React.ComponentType<CardProps>;
