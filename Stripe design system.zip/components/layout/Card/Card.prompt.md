Card from stripe-dashboard-ds. Use via `window.StripeDashboard.Card` (bundle loaded from the root `_ds_bundle.js`).

A bordered container for one chunk of content, with an optional title row.
@category layout

## Props

```ts
interface CardProps {
  /** Card title (16px bold). */
  title?: React.ReactNode;
  /** Info icon after the title. */
  info?: boolean;
  /** Top-right control, e.g. a close x or small Button. */
  action?: React.ReactNode;
  /** default (bordered), subdued (grey panel, no border) or selected (blurple border). */
  tone?: "default" | "subdued" | "selected";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Widget

```jsx
() => (
  <Card title="Invoices" info style={{ width: 320 }} action={<Button variant="ghost" size="sm" icon="x" aria-label="Remove widget" />}>
    <BreakdownBar segments={[{ label: 'Open', value: 8.88, display: 'MYR 8.88', color: 'blue-700' }, { label: 'Paid', value: 0, display: 'MYR 0.00', color: 'green-500' }]} />
  </Card>
)
```

### Subdued

```jsx
() => (
  <Card tone="subdued" title="Get started with Stripe" style={{ width: 320 }}>
    <span style={{ color: 'var(--text-subdued)' }}>Share a payment link or send an invoice. No code needed.</span>
    <Link href="#" arrow>Start</Link>
  </Card>
)
```

### Selected

```jsx
() => (
  <Card tone="selected" title="Sellers will collect payments directly" style={{ width: 320 }}>
    <span style={{ color: 'var(--text-subdued)' }}>Enable direct payments between buyers and sellers.</span>
  </Card>
)
```

## Related

`CardBrand`
