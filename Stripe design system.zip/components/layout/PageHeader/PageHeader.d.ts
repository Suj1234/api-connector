import * as React from 'react';

/**
 * PageHeader — from stripe-dashboard-ds@0.1.0.
 */
export interface PageHeaderProps {
  /** Page title (28px bold), e.g. "Transactions" or an amount "MYR 2.00". */
  title: React.ReactNode;
  /** Grey text after the title in regular weight, e.g. the currency "MYR". */
  titleSuffix?: React.ReactNode;
  /** Status Badge after the title. */
  badge?: React.ReactNode;
  /** Uppercase object-type eyebrow above the title, e.g. "Payment". */
  eyebrow?: string;
  /** Icon before the eyebrow. */
  eyebrowIcon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Line under the title, e.g. "Charged to <Link>Leonard Kim</Link>". */
  subtitle?: React.ReactNode;
  /** Breadcrumb above everything. */
  breadcrumb?: React.ReactNode;
  /** Buttons on the right; primary first for list pages. */
  actions?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const PageHeader: React.ComponentType<PageHeaderProps>;
