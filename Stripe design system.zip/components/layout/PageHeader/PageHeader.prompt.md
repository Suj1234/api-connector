PageHeader from stripe-dashboard-ds. Use via `window.StripeDashboard.PageHeader` (bundle loaded from the root `_ds_bundle.js`).

The top of a page: optional breadcrumb and eyebrow, a 28px title with badge, subtitle, and actions on the right.
@category layout

## Props

```ts
interface PageHeaderProps {
  /** Page title (28px bold), e.g. "Transactions" or an amount "MYR 2.00". */
  title: React.ReactNode;
  /** Grey text after the title in regular weight, e.g. the currency "MYR". */
  titleSuffix?: React.ReactNode;
  /** Status Badge after the title. */
  badge?: React.ReactNode;
  /** Uppercase object-type eyebrow above the title, e.g. "Payment". */
  eyebrow?: string;
  /** Icon before the eyebrow. */
  eyebrowIcon?: "info" | "home" | "balances" | "transactions" | "customers" | "product" | "payments" | "billing" | "reporting" | "more" | "search" | "plus" | "plus-circle" | "check" | "check-circle" | "x" | (string & {}) /* +26 more */;
  /** Line under the title, e.g. "Charged to <Link>Leonard Kim</Link>". */
  subtitle?: React.ReactNode;
  /** Breadcrumb above everything. */
  breadcrumb?: React.ReactNode;
  /** Buttons on the right; primary first for list pages. */
  actions?: React.ReactNode;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### ListPage

```jsx
() => (
  <div style={{ width: 860 }}>
    <PageHeader title="Transactions" actions={<><Button variant="primary" icon="plus">Create payment</Button><Button icon="reporting">Analyse</Button></>} />
  </div>
)
```

### DetailPage

```jsx
() => (
  <div style={{ width: 860 }}>
    <PageHeader eyebrow="Payment" eyebrowIcon="dollar" title="MYR 2.00" titleSuffix="MYR" badge={<Badge tone="success" icon="check">Succeeded</Badge>}
      subtitle={<>Charged to <Link href="#">Leonard Kim</Link></>}
      actions={<><Button size="sm" icon="refund">Refund</Button><Button size="sm" icon="dots" aria-label="More actions" /></>} />
  </div>
)
```

### WithBreadcrumb

```jsx
() => (
  <div style={{ width: 860 }}>
    <PageHeader breadcrumb={<Breadcrumb items={[{ label: 'Product catalogue', href: '#' }, { label: 'Features', href: '#' }]} />} title="Personal CS" badge={<Badge tone="success">Active</Badge>} actions={<Button variant="primary" size="sm">Attach to product</Button>} />
  </div>
)
```
