import * as React from 'react';

/**
 * FocusHeader — from stripe-dashboard-ds@0.1.0.
 */
export interface FocusHeaderProps {
  /** Task title, e.g. "Create invoice". */
  title: React.ReactNode;
  /** Muted autosave status, e.g. "Draft saved 10 seconds ago". */
  status?: React.ReactNode;
  /** Right-side buttons, primary last. */
  actions?: React.ReactNode;
  /** Close (x) handler; returns to the dashboard. */
  onClose?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const FocusHeader: React.ComponentType<FocusHeaderProps>;
