FocusHeader from stripe-dashboard-ds. Use via `window.StripeDashboard.FocusHeader` (bundle loaded from the root `_ds_bundle.js`).

The 52px header of full-screen task pages (create invoice, payment link): close, title, status and actions.
@category navigation

## Props

```ts
interface FocusHeaderProps {
  /** Task title, e.g. "Create invoice". */
  title: React.ReactNode;
  /** Muted autosave status, e.g. "Draft saved 10 seconds ago". */
  status?: React.ReactNode;
  /** Right-side buttons, primary last. */
  actions?: React.ReactNode;
  /** Close (x) handler; returns to the dashboard. */
  onClose?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### EditInvoice

```jsx
() => (
  <div style={{ width: 840 }}>
    <FocusHeader title="Edit invoice" status="Draft saved 10 seconds ago" actions={<><Button variant="ghost" size="sm" icon="bulb">Feedback?</Button><Button size="sm">Hide preview</Button><Button size="sm" variant="primary">Send invoice</Button></>} />
  </div>
)
```

### CreateLink

```jsx
() => (
  <div style={{ width: 840 }}>
    <FocusHeader title="Create a payment link" actions={<Button size="sm" variant="primary" iconEnd="check">Create link</Button>} />
  </div>
)
```
