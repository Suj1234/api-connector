import * as React from 'react';

/**
 * Tabs — from stripe-dashboard-ds@0.1.0.
 */
export interface TabsProps {
  /** Tab labels (or {label, value}). */
  items: (string | { label: string; value: string; })[];
  /** Selected value (defaults to the first). */
  value?: string;
  /** Called with the clicked value. */
  onChange?: (value: string) => void;
  /** md 14px (pages) or sm 13px (inside modals and previews). */
  size?: "sm" | "md";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Tabs: React.ComponentType<TabsProps>;
