Tabs from stripe-dashboard-ds. Use via `window.StripeDashboard.Tabs` (bundle loaded from the root `_ds_bundle.js`).

Underline tabs that switch views within a page; the selected tab is blurple with a 2px bar.
@category navigation

## Props

```ts
interface TabsProps {
  /** Tab labels (or {label, value}). */
  items: (string | { label: string; value: string; })[];
  /** Selected value (defaults to the first). */
  value?: string;
  /** Called with the clicked value. */
  onChange?: (value: string) => void;
  /** md 14px (pages) or sm 13px (inside modals and previews). */
  size?: "sm" | "md";
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Balances

```jsx
() => <div style={{ width: 520 }}><Tabs items={['Overview', 'All activity', 'Payouts']} /></div>
```

### Settings

```jsx
() => (
  <div style={{ width: 720 }}>
    <Tabs value="Business details" items={['Account details', 'Account status', 'Business details', 'Tax details', 'Branding', 'Custom domains']} />
  </div>
)
```

### Small

```jsx
() => <div style={{ width: 420 }}><Tabs size="sm" items={['Invoice PDF', 'Email', 'Hosted Invoice Page']} /></div>
```
