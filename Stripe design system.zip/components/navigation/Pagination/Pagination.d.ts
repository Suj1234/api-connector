import * as React from 'react';

/**
 * Pagination — from stripe-dashboard-ds@0.1.0.
 */
export interface PaginationProps {
  /** Result count text, e.g. "6 results". */
  summary: React.ReactNode;
  /** Enables Previous. */
  hasPrevious?: boolean;
  /** Enables Next. */
  hasNext?: boolean;
  /** Previous handler. */
  onPrevious?: () => void;
  /** Next handler. */
  onNext?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Pagination: React.ComponentType<PaginationProps>;
