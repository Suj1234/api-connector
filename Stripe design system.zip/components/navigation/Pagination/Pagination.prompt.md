Pagination from stripe-dashboard-ds. Use via `window.StripeDashboard.Pagination` (bundle loaded from the root `_ds_bundle.js`).

Result count on the left and small Previous / Next buttons on the right; no page numbers.
@category navigation

## Props

```ts
interface PaginationProps {
  /** Result count text, e.g. "6 results". */
  summary: React.ReactNode;
  /** Enables Previous. */
  hasPrevious?: boolean;
  /** Enables Next. */
  hasNext?: boolean;
  /** Previous handler. */
  onPrevious?: () => void;
  /** Next handler. */
  onNext?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### FirstPage

```jsx
() => <div style={{ width: 640 }}><Pagination summary="6 results" hasNext /></div>
```

### LastPage

```jsx
() => <div style={{ width: 640 }}><Pagination summary="2 results" hasPrevious /></div>
```
