import * as React from 'react';

/**
 * Sidebar — from stripe-dashboard-ds@0.1.0.
 */
export interface SidebarProps {
  /** Account name at the top, e.g. "Content-mobbin". */
  accountName: string;
  /** Two-letter mark in the square logo tile. */
  accountInitials?: string;
  /** Navigation groups in order. */
  sections: SidebarSection[];
  /** Item pinned at the bottom, e.g. { label: 'Developers', icon: 'code' }. */
  footerItem?: SidebarItem;
  /** Called with the clicked item. */
  onNavigate?: (item: SidebarItem) => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Sidebar: React.ComponentType<SidebarProps>;
