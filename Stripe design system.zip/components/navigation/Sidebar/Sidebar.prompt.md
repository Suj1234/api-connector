Sidebar from stripe-dashboard-ds. Use via `window.StripeDashboard.Sidebar` (bundle loaded from the root `_ds_bundle.js`).

The dashboard's 244px left navigation: account switcher, grouped items with icons, blurple current page.
@category navigation

## Props

```ts
interface SidebarProps {
  /** Account name at the top, e.g. "Content-mobbin". */
  accountName: string;
  /** Two-letter mark in the square logo tile. */
  accountInitials?: string;
  /** Navigation groups in order. */
  sections: SidebarSection[];
  /** Item pinned at the bottom, e.g. { label: 'Developers', icon: 'code' }. */
  footerItem?: SidebarItem;
  /** Called with the clicked item. */
  onNavigate?: (item: SidebarItem) => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Dashboard

```jsx
() => (
  <div style={{ height: 560, display: 'flex' }}>
    <Sidebar accountName="Content-mobbin" accountInitials="CM" footerItem={{ label: 'Developers', icon: 'code' }} sections={[
  { items: [
    { label: 'Home', icon: 'home' },
    { label: 'Balances', icon: 'balances' },
    { label: 'Transactions', icon: 'transactions', current: true },
    { label: 'Customers', icon: 'customers' },
    { label: 'Product catalogue', icon: 'product' },
  ] },
  { label: 'Shortcuts', items: [{ label: 'Invoices', icon: 'clock' }] },
  { label: 'Products', items: [
    { label: 'Payments', icon: 'payments', expandable: true },
    { label: 'Billing', icon: 'billing', children: [{ label: 'Overview' }, { label: 'Subscriptions' }, { label: 'Invoices' }] },
    { label: 'Reporting', icon: 'reporting', expandable: true },
    { label: 'More', icon: 'more', expandable: true },
  ] },
]} />
  </div>
)
```
