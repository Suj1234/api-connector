TopBar from stripe-dashboard-ds. Use via `window.StripeDashboard.TopBar` (bundle loaded from the root `_ds_bundle.js`).

The 60px bar above every page: search, Test mode switch, app/help/notification/settings icons and quick create.
@category navigation

## Props

```ts
interface TopBarProps {
  /** Search placeholder (default "Search"). */
  searchPlaceholder?: string;
  /** Test mode switch state. */
  testMode?: boolean;
  /** Called when Test mode is toggled. */
  onTestModeChange?: (on: boolean) => void;
  /** Shows the unread dot on the bell. */
  unread?: boolean;
  /** Called by the round plus (quick create). */
  onCreate?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### Default

```jsx
() => <div style={{ width: 840 }}><TopBar unread /></div>
```

### TestModeOn

```jsx
() => <div style={{ width: 840 }}><TopBar testMode /></div>
```
