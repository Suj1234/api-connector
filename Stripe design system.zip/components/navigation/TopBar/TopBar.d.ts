import * as React from 'react';

/**
 * TopBar — from stripe-dashboard-ds@0.1.0.
 */
export interface TopBarProps {
  /** Search placeholder (default "Search"). */
  searchPlaceholder?: string;
  /** Test mode switch state. */
  testMode?: boolean;
  /** Called when Test mode is toggled. */
  onTestModeChange?: (on: boolean) => void;
  /** Shows the unread dot on the bell. */
  unread?: boolean;
  /** Called by the round plus (quick create). */
  onCreate?: () => void;
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const TopBar: React.ComponentType<TopBarProps>;
