import * as React from 'react';

/**
 * Stepper — from stripe-dashboard-ds@0.1.0.
 */
export interface StepperProps {
  /** Steps in order. */
  steps: StepperStep[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Stepper: React.ComponentType<StepperProps>;
