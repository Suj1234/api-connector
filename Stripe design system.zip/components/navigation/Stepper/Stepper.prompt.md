Stepper from stripe-dashboard-ds. Use via `window.StripeDashboard.Stepper` (bundle loaded from the root `_ds_bundle.js`).

The vertical progress list on the left of onboarding and setup flows.
@category navigation

## Props

```ts
interface StepperProps {
  /** Steps in order. */
  steps: StepperStep[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### ActivatePayments

```jsx
() => (
  <Stepper steps={[
    { label: 'Verify your business', status: 'done' },
    { label: 'Add your bank', status: 'done' },
    { label: 'Secure your account', status: 'active', substeps: [{ label: 'Two-step authentication', current: true }] },
    { label: 'Add extras', status: 'pending' },
    { label: 'Review and finish', status: 'pending' },
  ]} />
)
```

### FirstStep

```jsx
() => (
  <Stepper steps={[
    { label: 'Verify your business', status: 'active', substeps: [{ label: 'Business type' }, { label: 'Personal details', current: true }, { label: 'Business details' }, { label: 'Public details' }] },
    { label: 'Add your bank', status: 'pending' },
    { label: 'Secure your account', status: 'pending' },
  ]} />
)
```
