import * as React from 'react';

/**
 * Breadcrumb — from stripe-dashboard-ds@0.1.0.
 */
export interface BreadcrumbProps {
  /** Ancestors only; the current page is the title below. */
  items: { label: string; href?: string; }[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}

export declare const Breadcrumb: React.ComponentType<BreadcrumbProps>;
