Breadcrumb from stripe-dashboard-ds. Use via `window.StripeDashboard.Breadcrumb` (bundle loaded from the root `_ds_bundle.js`).

A short blurple trail above a detail title ("Product catalogue › Features ›").
@category navigation

## Props

```ts
interface BreadcrumbProps {
  /** Ancestors only; the current page is the title below. */
  items: { label: string; href?: string; }[];
  className?: string;
  id?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}
```

## Examples

### TwoLevels

```jsx
() => <Breadcrumb items={[{ label: 'Product catalogue', href: '#' }, { label: 'Features', href: '#' }]} />
```

### OneLevel

```jsx
() => <Breadcrumb items={[{ label: 'Settings', href: '#' }]} />
```
