# Stripe Dashboard: how to build with it

An unofficial React design system that recreates the Stripe web dashboard: white surfaces, cool grays, one blurple (`--brand`, #635bff) for anything actionable, and tinted status badges. Every component is on `window.StripeDashboard`.

## Setup

- No provider or wrapper is needed. `styles.css` loads and sets the base font (Ubuntu Sans, from Google Fonts), 14/20 text and `--text` colour on `body`. Components are styled by `.sd-*` classes that read CSS variables.
- Build pages from the frame: `<AppShell sidebar={<Sidebar …/>} topBar={<TopBar …/>}>…</AppShell>`. Pass `testMode` to show the orange Test mode bar.
- Before styling, read `_ds/<folder>/styles.css` (tokens + component classes) and each component's `.prompt.md`.

## Styling your own layout glue

Use the tokens, never raw hex:
- Surfaces: `var(--surface)` (white), `var(--surface-subdued)` (#f6f8fa panels, hovers).
- Text: `var(--text)`, `var(--text-heading)`, `var(--text-subdued)` (labels), `var(--text-muted)` (timestamps, help), `var(--text-link)`.
- Lines: `var(--border)` (dividers, card outlines), `var(--border-strong)` (control borders, rule under section titles).
- Status: `var(--green-500)`, `var(--red-500)`, `var(--blue-700)`, `var(--yellow-700)`; chart series `var(--purple-400)`, `var(--orange-600)`.
- Spacing: `var(--space-1)` 4px … `var(--space-2)` 8, `--space-3` 12, `--space-4` 16, `--space-6` 24, `--space-8` 32. Radius: `--radius-sm` 6px controls, `--radius-md` 8px cards and popovers.
- Type classes: `.title` (28/36 bold page title), `.heading` (20/28 section), `.heading-sm` (16/24), `.body`, `.caption` (12/16), `.overline`, `.metric`, `.code`.

## Composition rules

- One `Button variant="primary"` per view, right-most; `Cancel` or `Back` as a secondary to its left. Sentence-case, verb-first labels ("Create payment", "Refund MYR 0.50").
- List page: `PageHeader` (title + actions) → optional `Banner` → `CountTabs` → a row of `FilterChip` with small `Export` / `Edit columns` buttons → `Table` (with `Amount`, `Badge`, `CardBrand` cells) → `Pagination`.
- Detail page: `PageHeader eyebrow="Payment" titleSuffix="MYR" badge={<Badge tone="success" icon="check">Succeeded</Badge>}` → `SectionTitle` + `Timeline` / `BreakdownList`; a right rail of `DetailsList`.
- Status is always a `Badge` with a word (success, danger, info, warning, neutral), never colour alone. Empty values render as an em dash.
- Money: currency code first, e.g. "MYR 2.00"; dates "6 Dec 2024, 00:42".
- Create flows: `Modal` for 1–3 fields, `Drawer` for one object, `FocusHeader` for full-screen tasks. Confirm with `Toast` ("Customer created").
- Icons: `<Icon name="…"/>` or the `icon` prop. Names: home, balances, transactions, customers, product, payments, billing, reporting, more, search, plus, plus-circle, check, check-circle, x, x-circle, chev-down, chev-right, chev-left, arrow-right, info, bell, gear, help, grid, calendar, clock, copy, external, export, edit, bulb, alert, lock, refund, columns, dollar, doc, code, dots, bag, eye.

## Example

```jsx
const { PageHeader, Button, Card, Metric, Table, Amount, Badge } = window.StripeDashboard;

<div style={{ display: 'grid', gap: 'var(--space-6)' }}>
  <PageHeader title="Balances" actions={<Button variant="primary">Pay out funds</Button>} />
  <Card title="MYR balance">
    <Metric label="Available to pay out" value="MYR 0.92" compare="Updated 06:23" />
  </Card>
  <Table
    rowKey={(r) => r.id}
    rows={[{ id: 'po_1', amount: 'MYR 5.00', status: 'Pending', bank: 'CIMB Bank •••• 7411', arrive: '13 Jan' }]}
    columns={[
      { key: 'amount', header: 'Amount', render: (r) => <Amount value={r.amount} currency="MYR" /> },
      { key: 'status', header: '', render: (r) => <Badge tone="warning">{r.status}</Badge> },
      { key: 'bank', header: 'Bank/card' },
      { key: 'arrive', header: 'Arrive by' },
    ]}
  />
</div>
```

# StripeDashboard (stripe-dashboard-ds@0.1.0)

This design system is the published stripe-dashboard-ds React library, bundled as a single
browser global. All 61 components are the real upstream code.

## Where things are

- `_ds_bundle.js` — the whole-DS bundle at the project root; loads every component to `window.StripeDashboard`. First line is a `/* @ds-bundle: … */` metadata header.
- `styles.css` — the single stylesheet entry: it `@import`s the tokens, fonts, and component styles (`_ds_bundle.css`). Link this one file.
- `components/<group>/<Name>/<Name>.prompt.md` (example JSX + variants), `<Name>.d.ts` (types), `<Name>.html` (variant grid).
- `tokens/*.css` — CSS custom properties, names verbatim from upstream.
- `fonts/` — `@font-face` files + `fonts.css` (when the package ships fonts).
- `guidelines/` — the design system's own usage guidance (1 doc(s), see `guidelines/index.md`). Read these before composing larger layouts.

For a specific component, `read_file("components/<group>/<Name>/<Name>.prompt.md")`.

## Loading

Add these two lines to your page once (React must be on the page first):

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
```

Components are then available at `window.StripeDashboard.*`. Mount into a dedicated child node (e.g. `<div id="ds-root">`), not the host page's own React root, so the two trees don't collide:

```jsx
const { Amount } = window.StripeDashboard;
ReactDOM.createRoot(document.getElementById('ds-root')).render(<Amount />);
```

## Tokens

87 CSS custom properties from stripe-dashboard-ds. Names are
preserved verbatim from upstream. They are declared inside `_ds_bundle.css` (this DS ships one compiled stylesheet rather than separate token files).

- **color** (9): `--surface`, `--surface-subdued`, `--text-heading`, …
- **spacing** (11): `--space-0-5`, `--space-1`, `--space-1-5`, …
- **typography** (3): `--font-sans`, `--font-mono`, `--font-display`
- **radius** (5): `--radius-xs`, `--radius-sm`, `--radius-md`, …
- **shadow** (5): `--shadow-control`, `--shadow-primary`, `--shadow-popover`, …
- **other** (54): `--white`, `--gray-50`, `--gray-100`, …

## Components

### data-display
- `Amount` — A money value in bold followed by its ISO currency code in grey (MYR 2.00 MYR), as in tables.
- `Badge` — The tinted status pill shown after amounts and titles: Succeeded, Failed, Open, Pending, Draft.
- `BreakdownBar` — A segmented 8px status bar with a legend of labelled values (payments or invoices by status).
- `BreakdownList` — Money lines with dividers and a bold total last: Payment amount, Stripe processing fees, Net amount.
- `CardBrand` — A payment-method cell: a small card-network chip followed by the masked last four digits.
- `ChartCard` — A Metric over a single-series line chart with a dashed previous period and a View more footer.
- `CodeBlock` — A light monospace panel for request and response bodies, with JSON colouring.
- `CountTabs` — Bordered status tiles above a list that filter it and show counts (All 6  Succeeded 1  Failed 3).
- `DetailsList` — Label/value pairs describing one object, stacked (details rail) or in two columns (summary).
- `EmptyState` — What a list or section shows before it has data: icon, title, one sentence and a create action.
- `IdChip` — An object ID or API key in Menlo 13px with a copy button, or as a blurple link.
- `Metric` — A KPI block: label with optional delta badge, a 20px value, and a comparison line.
- `RequestLog` — API request rows: status badge, method and path in monospace, time at the right.
- `Table` — The dashboard list table: bold 12px headers, 38px rows, checkbox and overflow columns, em-dash empty cells.
- `Tag` — A 16px label beside a field or feature name: New, Optional, Recommended, Default.
- `Timeline` — A vertical event history with status nodes on a hairline spine.

### layout
- `AppShell` — The full dashboard frame: optional test-mode bar, left Sidebar, TopBar and a padded page area.
- `AuthLayout` — Sign-in and sign-up screens: a white card over the skewed yellow-red-purple-cyan gradient band.
- `Card` — A bordered container for one chunk of content, with an optional title row.
- `PageHeader` — The top of a page: optional breadcrumb and eyebrow, a 28px title with badge, subtitle, and actions on the right.
- `SectionTitle` — A 20px bold in-page section heading with a rule under it and an optional action.

### feedback
- `Banner` — An inline page or section message: recommendation, critical account issue, warning, success or navy promo.
- `Drawer` — A right-side sheet for creating one object without leaving the list, with a sticky footer.
- `Modal` — A centred dialog over a grey-blue scrim with a title, a close x, a body and a right-aligned footer.
- `Spinner` — A blurple loading ring on a pale track.
- `TestModeBar` — The 28px orange bar pinned above the whole dashboard while Test mode is on.
- `Toast` — A dark pill confirming a completed action, with an optional Undo or View action.
- `Tooltip` — The small dark label for icon-only controls, optionally with a shortcut. Position it yourself next to its trigger.
- `TourPopover` — A navy 240px popover for one step of an in-product tour, with Skip tour and Next.

### navigation
- `Breadcrumb` — A short blurple trail above a detail title (Product catalogue  Features ).
- `FocusHeader` — The 52px header of full-screen task pages (create invoice, payment link): close, title, status and actions.
- `Pagination` — Result count on the left and small Previous / Next buttons on the right no page numbers.
- `Sidebar` — The dashboard's 244px left navigation: account switcher, grouped items with icons, blurple current page.
- `Stepper` — The vertical progress list on the left of onboarding and setup flows.
- `Tabs` — Underline tabs that switch views within a page the selected tab is blurple with a 2px bar.
- `TopBar` — The 60px bar above every page: search, Test mode switch, app/help/notification/settings icons and quick create.

### actions
- `Button` — The dashboard button: blurple primary, white bordered secondary, red danger, ghost and link variants.
- `Hint` — A term with a dashed underline that opens an explanation keeps the surrounding text colour.
- `Kbd` — A small keyboard-shortcut chip used inside buttons, menus and tooltips.
- `Link` — Inline blurple link, weight 600, no underline. For object references, View more, docs.
- `Menu` — A popover action list (overflow  menus, split buttons, quick create). Compose with MenuItem, MenuLabel, MenuSeparator.
- `MenuItem` — One row of a Menu.
- `MenuLabel` — A small grey group heading inside a Menu.
- `MenuSeparator` — A 1px divider between groups in a Menu.
- `PlusButton` — The round blurple quick-create button at the right of the top bar.

### forms
- `Checkbox` — A 16px checkbox that fills blurple when checked, with optional label and description.
- `ChoiceCard` — A bordered option button used as one choice of a radio group (pricing type, payment type, percentages).
- `ChoiceCardGroup` — Lays ChoiceCards out in equal columns that wrap on narrow screens.
- `ColorInput` — A colour swatch plus a monospace hex field, used in branding settings.
- `DatePicker` — A popover calendar (Monday-first) with an optional shortcuts column.
- `Field` — Stacks a label, a form control, help text and an error message.
- `FilterChip` — The dashed + Filter pill above lists turns solid and shows its value once applied.
- `OTPInput` — Six one-digit boxes in two groups of three for SMS and authenticator codes.
- `PasswordStrength` — A four-segment green strength meter under new-password fields.
- `Radio` — A radio option with a bold title and a muted description group options by giving them the same name.
- `SearchInput` — The borderless grey search field used in the top bar and list pages.
- `Select` — Native select with Stripe's stacked up/down chevron same box as TextInput.
- `Switch` — A 28x16 toggle for settings that apply immediately the Test mode switch turns orange.
- `Textarea` — Multi-line text input for descriptions, memos, footers and internal notes.
- `TextInput` — Single-line text input with optional currency prefix and trailing select.

### foundations
- `Icon` — A 16px, 1.5px-stroke line icon drawn in currentColor, matching the dashboard's icon weight.
